import io
import math
import pandas as pd
import streamlit as st
from datetime import date, datetime

from modules.pedido_models import load_clientes, load_trabajadores
from modules.presupuesto_form import render_presupuesto_form
from modules.presupuesto_detalle import render_presupuesto_detalle

# ======================
# Helpers
# ======================
def _safe(val, default="-"):
    return val if val not in (None, "", "null") else default

def _range(page: int, page_size: int):
    start = (page - 1) * page_size
    end = start + page_size - 1
    return start, end

def _load_estados_presupuesto(supabase) -> dict:
    try:
        rows = supabase.table("estado_presupuesto").select("*").order("estado_presupuestoid").execute().data or []
        return {r["nombre"]: r["estado_presupuestoid"] for r in rows}
    except Exception:
        return {}

def _label_from(catalog: dict, id_val) -> str:
    if not id_val:
        return "-"
    for k, v in (catalog or {}).items():
        if v == id_val:
            return k
    return "-"

def _is_bloqueado(estado_nombre: str) -> bool:
    if not estado_nombre:
        return False
    e = estado_nombre.lower()
    return ("acept" in e) or ("convertido" in e)

# ======================
# Conversión Presupuesto → Pedido
# ======================
def convertir_presupuesto_a_pedido(supabase, presupuestoid: int):
    """
    Duplica presupuesto + líneas en pedido/pedido_detalle
    y marca el presupuesto como 'Convertido a pedido'.
    """
    # 1️⃣ Obtener presupuesto
    pres = supabase.table("presupuesto").select("*").eq("presupuestoid", presupuestoid).single().execute().data
    if not pres:
        raise Exception("Presupuesto no encontrado.")

    # 2️⃣ Crear pedido cabecera
    pedido_payload = {
        "numero": f"P-{pres.get('numero')}",
        "clienteid": pres.get("clienteid"),
        "trabajadorid": pres.get("trabajadorid"),
        "tipo_pedidoid": 1,  # por defecto Venta
        "procedencia_pedidoid": 2,  # CRM
        "estado_pedidoid": 2,  # Pendiente
        "fecha_pedido": datetime.now().date().isoformat(),
        "referencia_cliente": pres.get("referencia_cliente"),
        "facturar_individual": pres.get("facturar_individual", False),
        "fecha_confirmada": None,
        "fecha_limite": None,
        "justificante_pago_url": None,
        "formapagoid": None,
    }

    pedido_res = supabase.table("pedido").insert(pedido_payload).execute()
    pedidoid = pedido_res.data[0]["pedidoid"]

    # 3️⃣ Copiar líneas
    lineas = supabase.table("presupuesto_detalle").select("*").eq("presupuestoid", presupuestoid).execute().data or []
    for l in lineas:
        supabase.table("pedido_detalle").insert({
            "pedidoid": pedidoid,
            "productoid": l.get("productoid"),
            "nombre_producto": l.get("descripcion"),
            "cantidad": l.get("cantidad"),
            "precio_unitario": l.get("precio_unitario"),
            "descuento_pct": l.get("descuento_pct"),
            "importe_total_linea": l.get("total_linea"),
        }).execute()

    # 4️⃣ Actualizar presupuesto
    try:
        estado_conv = supabase.table("estado_presupuesto").select("estado_presupuestoid").eq("nombre", "Convertido a pedido").single().execute().data
        estadoid_conv = estado_conv["estado_presupuestoid"] if estado_conv else None
    except Exception:
        estadoid_conv = None

    supabase.table("presupuesto").update({
        "estado_presupuestoid": estadoid_conv,
        "editable": False,
        "fecha_conversion": datetime.now().isoformat(timespec="seconds")
    }).eq("presupuestoid", presupuestoid).execute()

    return pedidoid


# ======================
# Render principal
# ======================
def render_presupuesto_lista(supabase):
    st.header("💼 Gestión de presupuestos")
    st.caption("Visualiza, edita y convierte tus presupuestos en pedidos. Diseño tipo 'productos', con ficha completa desplegable y bloqueo por estado.")

    # Estado UI
    if "pres_page" not in st.session_state:
        st.session_state.pres_page = 1
    if "pres_view" not in st.session_state:
        st.session_state.pres_view = "Tarjetas"
    if "show_presupuesto_modal" not in st.session_state:
        st.session_state.show_presupuesto_modal = False
    if "presupuesto_modal_id" not in st.session_state:
        st.session_state.presupuesto_modal_id = None

    page_size_cards, page_size_table = 12, 30

    clientes = load_clientes(supabase)
    trabajadores = load_trabajadores(supabase)
    estados = _load_estados_presupuesto(supabase)

    # Filtros
    c1, c2, c3 = st.columns([2, 1, 1])
    with c1:
        q = st.text_input("🔎 Buscar", placeholder="Número o referencia…", key="pres_q")
    with c2:
        estado_sel = st.selectbox("Estado", ["Todos"] + list(estados.keys()), key="pres_estado")
    with c3:
        view = st.radio("Vista", ["Tarjetas", "Tabla"], horizontal=True, key="pres_view")

    if st.button("➕ Nuevo presupuesto", use_container_width=True):
        st.session_state["presupuesto_modal_id"] = None
        st.session_state["show_presupuesto_modal"] = True
        st.rerun()

    st.markdown("---")

    # Consulta
    total, rows = 0, []
    try:
        base_count = supabase.table("presupuesto").select("presupuestoid", count="exact")
        if q:
            base_count = base_count.or_(f"numero.ilike.%{q}%,referencia_cliente.ilike.%{q}%")
        if estado_sel != "Todos":
            base_count = base_count.eq("estado_presupuestoid", estados[estado_sel])
        cres = base_count.execute()
        total = getattr(cres, "count", None) or len(cres.data or [])

        per_page = page_size_cards if view == "Tarjetas" else page_size_table
        start, end = _range(st.session_state.pres_page, per_page)

        base = supabase.table("presupuesto").select("*")
        if q:
            base = base.or_(f"numero.ilike.%{q}%,referencia_cliente.ilike.%{q}%")
        if estado_sel != "Todos":
            base = base.eq("estado_presupuestoid", estados[estado_sel])
        rows = base.order("fecha_presupuesto", desc=True).range(start, end).execute().data or []
    except Exception as e:
        st.error(f"❌ Error cargando presupuestos: {e}")

    # Paginación
    total_pages = max(1, math.ceil(total / (page_size_cards if view == "Tarjetas" else page_size_table)))
    st.caption(f"Mostrando página {st.session_state.pres_page} de {total_pages} — Total: {total} presupuestos")

    p1, p2, p3, _ = st.columns([1, 1, 1, 5])
    if p1.button("⏮️", disabled=st.session_state.pres_page <= 1):
        st.session_state.pres_page = 1; st.rerun()
    if p2.button("◀️", disabled=st.session_state.pres_page <= 1):
        st.session_state.pres_page -= 1; st.rerun()
    if p3.button("▶️", disabled=st.session_state.pres_page >= total_pages):
        st.session_state.pres_page += 1; st.rerun()

    st.markdown("---")

    # Render
    if not rows:
        st.info("📭 No hay presupuestos que coincidan con los filtros.")
        return

    if view == "Tarjetas":
        cols = st.columns(3)
        for i, r in enumerate(rows):
            with cols[i % 3]:
                _render_card(r, supabase, clientes, trabajadores, estados)
    else:
        _render_table(rows)

    # Modal
    if st.session_state.get("show_presupuesto_modal"):
        _render_presupuesto_modal(supabase, clientes, trabajadores, estados)


# ======================
# Tarjeta
# ======================
def _render_card(r, supabase, clientes, trabajadores, estados):
    cli = _label_from(clientes, r.get("clienteid"))
    tra = _label_from(trabajadores, r.get("trabajadorid"))
    est_nombre = _label_from(estados, r.get("estado_presupuestoid"))
    bloqueado = _is_bloqueado(est_nombre)

    st.markdown(
        f"""
        <div style="border:1px solid #e5e7eb;border-radius:12px;padding:12px;margin-bottom:10px;background:#fff;">
            <div style="display:flex;justify-content:space-between;align-items:center;">
                <div><b>{_safe(r.get('numero'))}</b> — {_safe(cli)}</div>
                <span style="background:{('#10b981' if 'acept' in (est_nombre or '').lower() else ('#6b7280' if 'convert' in (est_nombre or '').lower() else '#3b82f6'))};color:#fff;padding:3px 8px;border-radius:8px;font-size:0.8rem;">
                    {est_nombre or '-'}
                </span>
            </div>
            <div style="margin-top:4px;color:#555;font-size:0.9rem;">
                📅 {_safe(r.get("fecha_presupuesto"))} &nbsp; | &nbsp; 💶 {_safe(r.get("total_estimada"))} €
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    a, b, c = st.columns(3)
    if a.button("📄 Ficha", key=f"pres_ficha_{r['presupuestoid']}", use_container_width=True):
        st.session_state["presupuesto_modal_id"] = r["presupuestoid"]
        st.session_state["show_presupuesto_modal"] = True
        st.rerun()
    if b.button("✏️ Editar", key=f"pres_edit_{r['presupuestoid']}", use_container_width=True, disabled=bloqueado):
        st.session_state["presupuesto_modal_id"] = r["presupuestoid"]
        st.session_state["show_presupuesto_modal"] = True
        st.rerun()
    if c.button("🚀 Convertir", key=f"pres_conv_{r['presupuestoid']}", use_container_width=True, disabled=not('acept' in (est_nombre or '').lower())):
        try:
            pedidoid = convertir_presupuesto_a_pedido(supabase, r["presupuestoid"])
            st.success(f"✅ Presupuesto convertido a pedido #{pedidoid}")
            st.rerun()
        except Exception as e:
            st.error(f"❌ Error al convertir: {e}")


# ======================
# Tabla
# ======================
def _render_table(rows):
    df = pd.DataFrame(rows)
    if df.empty:
        st.info("No hay presupuestos.")
        return
    cols = ["presupuestoid", "numero", "clienteid", "estado_presupuestoid", "fecha_presupuesto", "total_estimada"]
    st.dataframe(df[cols], use_container_width=True)
    buff = io.StringIO()
    df[cols].to_csv(buff, index=False)
    st.download_button("⬇️ Exportar CSV", buff.getvalue(), file_name=f"presupuestos_{date.today()}.csv", mime="text/csv")


# ======================
# Modal / Ficha
# ======================
def _render_presupuesto_modal(supabase, clientes, trabajadores, estados):
    pid = st.session_state.get("presupuesto_modal_id")
    if not pid:
        return

    try:
        r = supabase.table("presupuesto").select("*").eq("presupuestoid", pid).single().execute().data
    except Exception as e:
        st.error(f"❌ Error cargando presupuesto: {e}")
        return

    est_nombre = _label_from(estados, r.get("estado_presupuestoid"))
    bloqueado = _is_bloqueado(est_nombre)

    st.markdown("---")
    st.markdown(f"### 📄 Ficha del presupuesto {r.get('numero')} — Estado: {est_nombre}")

    # Botones superiores
    c1, c2, c3, c4 = st.columns([2, 1, 1, 1])
    with c1:
        if st.button("⬅️ Cerrar ficha", use_container_width=True):
            st.session_state["show_presupuesto_modal"] = False
            st.rerun()
    with c2:
        st.button("📑 Duplicar", use_container_width=True, disabled=True)
    with c3:
        if st.button("🗑️ Eliminar", use_container_width=True, disabled=bloqueado):
            try:
                supabase.table("presupuesto_detalle").delete().eq("presupuestoid", pid).execute()
                supabase.table("presupuesto").delete().eq("presupuestoid", pid).execute()
                st.success("🗑️ Presupuesto eliminado.")
                st.session_state["show_presupuesto_modal"] = False
                st.rerun()
            except Exception as e:
                st.error(f"❌ Error al eliminar: {e}")
    with c4:
        if st.button("🚀 Convertir a pedido", use_container_width=True, disabled=not('acept' in (est_nombre or '').lower())):
            try:
                pedidoid = convertir_presupuesto_a_pedido(supabase, pid)
                st.success(f"✅ Presupuesto convertido a pedido #{pedidoid}")
                st.rerun()
            except Exception as e:
                st.error(f"❌ Error al convertir: {e}")

    # Formulario y detalle
    render_presupuesto_form(supabase, presupuestoid=pid, bloqueado=bloqueado)
    st.markdown("---")
    render_presupuesto_detalle(supabase, presupuestoid=pid, bloqueado=bloqueado)
