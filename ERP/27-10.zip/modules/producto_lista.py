# modules/producto_lista.py
import io
import math
import pandas as pd
import streamlit as st
from datetime import date

from modules.producto_models import (
    load_familias,
    load_tipos_producto,
    load_impuestos,
    load_estados_producto,
    get_familia_label,
    get_tipo_label,
    get_impuesto_label,
    get_estado_label,
)

from modules.producto_form import render_producto_form


# ======================================================
# ⚙️ Utilidades
# ======================================================
def _safe(val, default="-"):
    return val if val not in (None, "", "null") else default


def _range(page: int, page_size: int):
    start = (page - 1) * page_size
    end = start + page_size - 1
    return start, end


def _build_search_or(s, fields=("nombre", "titulo", "referencia", "isbn", "ean")):
    s = (s or "").strip()
    if not s:
        return None
    return ",".join([f"{f}.ilike.%{s}%" for f in fields])


def _safe_catalog(loader):
    try:
        data = loader()
        return data if isinstance(data, dict) else {}
    except Exception as e:
        st.warning(f"⚠️ Catálogo no disponible: {e}")
        return {}


# ======================================================
# 🧱 Catálogo de productos (principal)
# ======================================================
def render_producto_lista(supabase):
    st.header("📦 Catálogo de productos")
    st.caption("Busca, filtra y gestiona el catálogo con ficha detallada, edición lateral y exportación CSV.")

    # Estado de sesión
    if "prod_page" not in st.session_state:
        st.session_state.prod_page = 1
    if "prod_view" not in st.session_state:
        st.session_state.prod_view = "Tarjetas"
    if "prod_sort" not in st.session_state:
        st.session_state.prod_sort = "nombre ASC"
    if "producto_show_form" not in st.session_state:
        st.session_state.producto_show_form = False
    if "producto_editar_id" not in st.session_state:
        st.session_state.producto_editar_id = None
    if "show_producto_modal" not in st.session_state:
        st.session_state.show_producto_modal = False
    if "producto_modal_id" not in st.session_state:
        st.session_state.producto_modal_id = None
    if "confirm_delete_producto" not in st.session_state:
        st.session_state.confirm_delete_producto = False

    page_size_cards, page_size_table = 12, 30

    # Catálogos
    familias = _safe_catalog(lambda: load_familias(supabase))
    tipos = _safe_catalog(lambda: load_tipos_producto(supabase))
    impuestos = _safe_catalog(lambda: load_impuestos(supabase))
    estados = _safe_catalog(lambda: load_estados_producto(supabase))

    # Filtros
    c1, c2, c3, c4 = st.columns([2, 2, 2, 1])
    with c1:
        q = st.text_input("🔎 Buscar", placeholder="Nombre, título, referencia, ISBN, EAN…", key="prod_q")
    with c2:
        familia_sel = st.selectbox("Familia", ["Todas"] + list(familias.keys()), key="prod_familia")
    with c3:
        tipo_sel = st.selectbox("Tipo", ["Todos"] + list(tipos.keys()), key="prod_tipo")
    with c4:
        view = st.radio("Vista", ["Tarjetas", "Tabla"], horizontal=True, key="prod_view")

    c5, c6, c7 = st.columns([2, 2, 2])
    with c5:
        estado_sel = st.selectbox("Estado", ["Todos"] + list(estados.keys()), key="prod_estado")
    with c6:
        ordenar = st.selectbox(
            "Ordenar por",
            [
                "nombre ASC", "nombre DESC",
                "fecha_publicacion DESC", "fecha_publicacion ASC",
                "precio_generico DESC", "precio_generico ASC"
            ],
            key="prod_sort",
        )
    with c7:
        if st.button("➕ Nuevo producto", use_container_width=True):
            st.session_state["producto_editar_id"] = None
            st.session_state["producto_show_form"] = True
            st.session_state["show_producto_modal"] = False

    st.markdown("---")

    # Query principal
    total, productos = 0, []
    try:
        base_count = supabase.table("producto").select("productoid", count="exact")
        or_filter = _build_search_or(q)
        if or_filter:
            base_count = base_count.or_(or_filter)
        if familia_sel != "Todas" and familia_sel in familias:
            base_count = base_count.eq("familia_productoid", familias[familia_sel])
        if tipo_sel != "Todos" and tipo_sel in tipos:
            base_count = base_count.eq("producto_tipoid", tipos[tipo_sel])
        if estado_sel != "Todos" and estado_sel in estados:
            base_count = base_count.eq("estado_productoid", estados[estado_sel])
        cres = base_count.execute()
        total = getattr(cres, "count", None) or len(cres.data or [])
        per_page = page_size_cards if view == "Tarjetas" else page_size_table
        start, end = _range(st.session_state.prod_page, per_page)

        base = supabase.table("producto").select("*")
        if or_filter:
            base = base.or_(or_filter)
        if familia_sel != "Todas" and familia_sel in familias:
            base = base.eq("familia_productoid", familias[familia_sel])
        if tipo_sel != "Todos" and tipo_sel in tipos:
            base = base.eq("producto_tipoid", tipos[tipo_sel])
        if estado_sel != "Todos" and estado_sel in estados:
            base = base.eq("estado_productoid", estados[estado_sel])
        if " " in ordenar:
            f, d = ordenar.split(" ")
            base = base.order(f, desc=(d.upper() == "DESC"))
        productos = (base.range(start, end).execute().data or [])
    except Exception as e:
        st.error(f"❌ Error cargando productos: {e}")

    # Paginación
    total_pages = max(1, math.ceil(total / (page_size_cards if view == "Tarjetas" else page_size_table)))
    st.caption(f"Mostrando página {st.session_state.prod_page} de {total_pages} — Total: {total} productos")

    p1, p2, p3, _ = st.columns([1, 1, 1, 5])
    if p1.button("⏮️", disabled=st.session_state.prod_page <= 1):
        st.session_state.prod_page = 1
        st.rerun()
    if p2.button("◀️", disabled=st.session_state.prod_page <= 1):
        st.session_state.prod_page -= 1
        st.rerun()
    if p3.button("▶️", disabled=st.session_state.prod_page >= total_pages):
        st.session_state.prod_page += 1
        st.rerun()
    st.markdown("---")

    # Render
    if not productos:
        st.info("📭 No hay productos que coincidan con los filtros.")
        return

    if view == "Tarjetas":
        cols = st.columns(3)
        for i, p in enumerate(productos):
            with cols[i % 3]:
                _render_card(p, supabase)
    else:
        _render_table(productos, supabase)

    # Ficha desplegable
    if st.session_state.get("show_producto_modal"):
        render_producto_modal(supabase)


# ======================================================
# 💳 Tarjetas
# ======================================================
def _render_card(p, supabase):
    nombre, titulo = _safe(p.get("nombre")), _safe(p.get("titulo"))
    precio = p.get("precio_generico")
    precio_str = f"{float(precio):.2f} €" if isinstance(precio, (int, float)) else "-"
    tipo_lbl = get_tipo_label(p.get("producto_tipoid"), supabase)
    familia_lbl = get_familia_label(p.get("familia_productoid"), supabase)
    estado_lbl = get_estado_label(p.get("estado_productoid"), supabase)
    portada = p.get("portada_url") or ""

    st.markdown(
        f"""
        <div style="border:1px solid #e5e7eb;border-radius:14px;padding:10px;background:#fafafa;">
            <div style="display:flex;gap:10px;">
                <div style="width:90px;height:120px;border:1px solid #ddd;border-radius:8px;overflow:hidden;">
                    {'<img src="'+portada+'" style="width:100%;height:100%;object-fit:cover;" />' if portada else '📘'}
                </div>
                <div style="flex:1;">
                    <div style="font-weight:600;font-size:1.1rem;">{nombre}</div>
                    <div style="color:#666;">{titulo}</div>
                    <div style="margin-top:4px;">💶 <b>{precio_str}</b> | 🏷️ {tipo_lbl} · {familia_lbl} | ⚙️ {estado_lbl}</div>
                </div>
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    a, b, c = st.columns([1, 1, 1])
    if a.button("📄 Ficha", key=f"ficha_prod_{p['productoid']}"):
        st.session_state["producto_modal_id"] = p["productoid"]
        st.session_state["show_producto_modal"] = True
        st.rerun()
    if b.button("✏️ Editar", key=f"edit_prod_{p['productoid']}"):
        st.session_state["producto_editar_id"] = p["productoid"]
        st.session_state["producto_show_form"] = True
        st.session_state["show_producto_modal"] = False
        st.rerun()
    c.button("📑 Duplicar", key=f"dup_prod_{p['productoid']}", disabled=True)


# ======================================================
# 📋 Tabla
# ======================================================
def _render_table(productos, supabase):
    df = pd.DataFrame(productos)
    if df.empty:
        st.info("No hay productos.")
        return
    st.dataframe(df, use_container_width=True)
    buff = io.StringIO()
    df.to_csv(buff, index=False)
    st.download_button("⬇️ Exportar CSV", buff.getvalue(), file_name=f"productos_{date.today()}.csv", mime="text/csv")


# ======================================================
# 🧩 Modal del producto (detalle → editar)
# ======================================================
def render_producto_modal(supabase):
    pid = st.session_state.get("producto_modal_id")
    if not pid:
        return

    st.markdown("---")
    st.markdown("### 📘 Ficha del producto")

    # Botones superiores
    c1, c2 = st.columns([2, 1])
    if c1.button("⬅️ Cerrar ficha"):
        st.session_state["show_producto_modal"] = False
        st.rerun()
    if c2.button("🗑️ Eliminar producto"):
        try:
            supabase.table("producto").delete().eq("productoid", pid).execute()
            st.success("🗑️ Producto eliminado correctamente.")
            st.session_state["show_producto_modal"] = False
            st.rerun()
        except Exception as e:
            st.error(f"❌ Error al eliminar: {e}")

    # Cargar datos
    try:
        p = supabase.table("producto").select("*").eq("productoid", pid).single().execute().data
    except Exception as e:
        st.error(f"❌ Error cargando producto: {e}")
        return

    tipo_lbl = get_tipo_label(p.get("producto_tipoid"), supabase)
    familia_lbl = get_familia_label(p.get("familia_productoid"), supabase)
    impuesto_lbl = get_impuesto_label(p.get("impuestoid"), supabase)
    estado_lbl = get_estado_label(p.get("estado_productoid"), supabase)

    # 🔎 Primero ver detalle
    with st.expander("🔎 Ver detalle del producto", expanded=True):
        cols = st.columns([1, 2])
        with cols[0]:
            if p.get("portada_url"):
                st.image(p["portada_url"], use_container_width=True)
            st.write("**💶 Precio genérico:**", p.get("precio_generico"))
            st.write("**🧾 Impuesto:**", impuesto_lbl)
            st.write("**⚙️ Estado:**", estado_lbl)
            st.write("**📅 Fecha publicación:**", p.get("fecha_publicacion"))
        with cols[1]:
            st.write("**Nombre:**", p.get("nombre"))
            st.write("**Título:**", p.get("titulo"))
            st.write("**Referencia:**", p.get("referencia"))
            st.write("**ISBN:**", p.get("isbn"))
            st.write("**EAN:**", p.get("ean"))
            st.write("**Versatilidad:**", p.get("versatilidad") or "-")
            st.write("**Familia:**", familia_lbl)
            st.write("**Tipo:**", tipo_lbl)
            st.write("**Sinopsis:**")
            st.info(p.get("sinopsis") or "-")

    # ✏️ Luego editor
    st.markdown("---")
    st.subheader("✏️ Editar producto")
    try:
        render_producto_form(supabase, productoid=pid, on_saved_rerun=True)
    except Exception as e:
        st.error(f"❌ Error al abrir el formulario: {e}")
