# ======================================================
# 💸 MÓDULO DE CÁLCULO DE PRECIOS — EnteNova Gnosis
# ======================================================
# Aplica la lógica de tarifas (reglas de descuento) y de impuestos (IVA),
# devolviendo un desglose completo de precios por línea de pedido.
#
# Jerarquía de búsqueda de descuentos:
# 1️⃣ producto + cliente
# 2️⃣ familia + cliente
# 3️⃣ producto + grupo
# 4️⃣ familia + grupo
# 5️⃣ sin coincidencia → sin descuento

import math
from datetime import date

# ======================================================
# 🧠 Función principal
# ======================================================
def calcular_precio_linea(supabase, clienteid=None, productoid=None,
                          precio_base_unit=None, cantidad=1.0, fecha=None):
    """
    Calcula el precio total de una línea considerando:
    - Descuento por tarifa_regla (cliente/grupo + producto/familia)
    - Impuesto del producto (columna impuestoid)
    - Precio base indicado o del producto si existe

    Devuelve un diccionario:
    {
        "unit_bruto": precio_base_unit,
        "unit_neto_sin_iva": float,
        "subtotal_sin_iva": float,
        "iva_pct": float,
        "iva_importe": float,
        "total_con_iva": float,
        "tarifa_aplicada": str | None,
        "descuento_pct": float,
    }
    """

    fecha = fecha or date.today()
    descuento_pct = 0.0
    tarifa_nombre = None
    iva_pct = 0.0
    familiaid = None
    grupoid = None

    # ======================================================
    # 🧾 1. Obtener datos del producto
    # ======================================================
    prod = None
    if productoid:
        try:
            prod = (
                supabase.table("producto")
                .select("productoid, familia_productoid, precio_generico, impuestoid")
                .eq("productoid", productoid)
                .single()
                .execute()
                .data
            )
            if prod:
                precio_base_unit = precio_base_unit or float(prod.get("precio_generico") or 0.0)
                familiaid = prod.get("familia_productoid")
        except Exception as e:
            print(f"[precio_engine] Error cargando producto: {e}")

    # ======================================================
    # 👥 2. Obtener grupo del cliente (si tiene)
    # ======================================================
    if clienteid:
        try:
            cli = (
                supabase.table("cliente")
                .select("clienteid, grupoid")
                .eq("clienteid", clienteid)
                .single()
                .execute()
                .data
            )
            if cli:
                grupoid = cli.get("grupoid")
        except Exception as e:
            print(f"[precio_engine] Error cargando cliente: {e}")

    # ======================================================
    # 💰 3. Buscar regla de tarifa más específica activa
    # ======================================================
    reglas = []
    try:
        reglas = (
            supabase.table("tarifa_regla")
            .select("tarifa_reglaid, tarifaid, clienteid, grupoid, productoid, familia_productoid, descuento_pct, precio_fijo, fecha_inicio, fecha_fin, prioridad, habilitada")
            .eq("habilitada", True)
            .lte("fecha_inicio", fecha.isoformat())
            .or_(f"fecha_fin.is.null,fecha_fin.gte.{fecha.isoformat()}")
            .order("prioridad", desc=False)
            .execute()
            .data or []
        )
    except Exception as e:
        print(f"[precio_engine] Error cargando reglas de tarifa: {e}")

    # Jerarquía 1→4
    for nivel, filtro in enumerate([
        lambda r: r["productoid"] == productoid and r["clienteid"] == clienteid,
        lambda r: r["familia_productoid"] == familiaid and r["clienteid"] == clienteid,
        lambda r: r["productoid"] == productoid and r["grupoid"] == grupoid,
        lambda r: r["familia_productoid"] == familiaid and r["grupoid"] == grupoid,
    ]):
        seleccionadas = [r for r in reglas if filtro(r)]
        if seleccionadas:
            regla = seleccionadas[0]
            descuento_pct = float(regla.get("descuento_pct") or 0.0)
            # Obtener nombre de la tarifa
            try:
                t = (
                    supabase.table("tarifa")
                    .select("nombre")
                    .eq("tarifaid", regla["tarifaid"])
                    .single()
                    .execute()
                    .data
                )
                tarifa_nombre = t.get("nombre") if t else None
            except Exception:
                tarifa_nombre = None
            break  # se encontró una regla válida

    # ======================================================
    # 💶 4. Calcular precio base neto y descuento
    # ======================================================
    unit_bruto = float(precio_base_unit or 0.0)
    unit_neto = unit_bruto * (1 - descuento_pct / 100.0)
    subtotal = unit_neto * float(cantidad)

    # ======================================================
    # 🧾 5. Aplicar IVA del producto
    # ======================================================
    if prod and prod.get("impuestoid"):
        try:
            imp = (
                supabase.table("impuesto")
                .select("porcentaje, tipo_producto, pais")
                .eq("impuestoid", prod["impuestoid"])
                .single()
                .execute()
                .data
            )
            if imp:
                iva_pct = float(imp.get("porcentaje") or 0.0)
        except Exception as e:
            print(f"[precio_engine] Error cargando impuesto: {e}")

    iva_importe = subtotal * (iva_pct / 100.0)
    total = subtotal + iva_importe

    # ======================================================
    # 🧾 6. Resultado final
    # ======================================================
    return {
        "unit_bruto": round(unit_bruto, 2),
        "unit_neto_sin_iva": round(unit_neto, 2),
        "subtotal_sin_iva": round(subtotal, 2),
        "iva_pct": round(iva_pct, 2),
        "iva_importe": round(iva_importe, 2),
        "total_con_iva": round(total, 2),
        "tarifa_aplicada": tarifa_nombre,
        "descuento_pct": round(descuento_pct, 2),
    }
