# ======================================================
# ⚠️ Gestión de incidencias — versión adaptada a tu BBDD real
# ======================================================
import streamlit as st
import pandas as pd
from datetime import datetime
from modules.pedido_models import load_trabajadores

# ======================================================
# 🎯 VISTA PRINCIPAL — INCIDENCIAS
# ======================================================
def render_incidencia_lista(supabase):
    st.header("⚠️ Gestión de incidencias")
    st.caption("Monitorea y resuelve incidencias relacionadas con clientes, pedidos o productos.")

    session = st.session_state
    session.setdefault("inci_view", "Tarjetas")

    trabajadores = load_trabajadores(supabase)

    # ----------------------------
    # Filtros
    # ----------------------------
    col1, col2, col3, col4 = st.columns([2, 2, 2, 1])
    with col1:
        tipo_sel = st.selectbox("Origen tipo", ["Todos", "cliente", "pedido", "producto"])
    with col2:
        estado_sel = st.selectbox("Estado", ["Todos", "Abierta", "En curso", "Cerrada", "Solucionada", "Rechazada"])
    with col3:
        asignado_sel = st.selectbox("Responsable", ["Todos"] + list(trabajadores.keys()))
    with col4:
        view = st.radio("Vista", ["Tarjetas", "Tabla"], horizontal=True, key="inci_view")

    # ----------------------------
    # Query principal
    # ----------------------------
    incidencias = []
    try:
        base = supabase.table("incidencia").select("*")
        if tipo_sel != "Todos":
            base = base.eq("origen_tipo", tipo_sel)
        if estado_sel != "Todos":
            base = base.eq("estado", estado_sel)
        if asignado_sel != "Todos":
            base = base.eq("responsableid", trabajadores[asignado_sel])

        data = base.order("fecha_creacion", desc=True).limit(100).execute()
        incidencias = data.data or []
    except Exception as e:
        st.error(f"❌ Error cargando incidencias: {e}")

    if not incidencias:
        st.info("📭 No hay incidencias que coincidan con los filtros.")
        return

    # ----------------------------
    # KPIs rápidos
    # ----------------------------
    total = len(incidencias)
    abiertas = sum(1 for i in incidencias if str(i.get("estado", "")).lower().startswith("abier"))
    curso = sum(1 for i in incidencias if "curso" in str(i.get("estado", "")).lower())
    sol = sum(1 for i in incidencias if "solu" in str(i.get("estado", "")).lower())

    m1, m2, m3, m4 = st.columns(4)
    m1.metric("🔢 Total", total)
    m2.metric("🟠 Abiertas", abiertas)
    m3.metric("🟡 En curso", curso)
    m4.metric("🟢 Solucionadas", sol)

    # ----------------------------
    # Render listado
    # ----------------------------
    if view == "Tarjetas":
        cols = st.columns(2)
        for idx, i in enumerate(incidencias):
            with cols[idx % 2]:
                _render_incidencia_card(i, trabajadores)
    else:
        _render_incidencia_table(incidencias, trabajadores)

    # Modal de detalle
    if st.session_state.get("inci_show_modal"):
        render_incidencia_detalle(supabase)


# ======================================================
# 💳 TARJETAS
# ======================================================
def _render_incidencia_card(i, trabajadores):
    estado = i.get("estado", "-")
    trabajador = _label(trabajadores, i.get("responsableid"))
    tipo = i.get("origen_tipo", "-")

    color = "#9ca3af"
    est = estado.lower()
    if "abier" in est: color = "#f59e0b"
    elif "curso" in est: color = "#3b82f6"
    elif "solu" in est or "cerr" in est: color = "#10b981"
    elif "rech" in est: color = "#ef4444"

    st.markdown(f"""
    <div style='border:1px solid #ddd;border-radius:10px;padding:10px;margin-bottom:10px;background:#fff;'>
        <div style='display:flex;justify-content:space-between;'>
            <b>#{i['incidenciaid']} · {tipo}</b>
            <span style='background:{color};color:#fff;padding:2px 8px;border-radius:8px;font-size:0.8rem;'>{estado}</span>
        </div>
        <p style='margin-top:6px;'><b>{i.get('tipo','-')}</b> — {i.get('descripcion','')}</p>
        <p style='color:#555;font-size:0.85rem;'>👤 {trabajador or '-'} · 📅 {i.get('fecha_creacion','')}</p>
    </div>
    """, unsafe_allow_html=True)

    col1, col2 = st.columns(2)
    with col1:
        if st.button("📄 Detalle", key=f"detalle_{i['incidenciaid']}", use_container_width=True):
            st.session_state["inci_detalle_id"] = i["incidenciaid"]
            st.session_state["inci_show_modal"] = True
            st.rerun()
    with col2:
        st.button("✅ Marcar solucionada", key=f"solve_{i['incidenciaid']}", use_container_width=True)


# ======================================================
# 📋 TABLA
# ======================================================
def _render_incidencia_table(data, trabajadores):
    df = pd.DataFrame(data)
    if df.empty:
        st.info("No hay incidencias.")
        return
    show_cols = [c for c in ["incidenciaid", "tipo", "descripcion", "estado", "responsableid", "fecha_creacion"] if c in df.columns]
    st.dataframe(df[show_cols], use_container_width=True)


# ======================================================
# 🔧 HELPERS
# ======================================================
def _label(d: dict, idv):
    for k, v in (d or {}).items():
        if v == idv:
            return k
    return "-"


# ======================================================
# 🧩 MODAL DETALLE / EDICIÓN
# ======================================================
def render_incidencia_detalle(supabase):
    """Muestra el detalle y permite editar la incidencia."""
    incidenciaid = st.session_state.get("inci_detalle_id")
    if not incidenciaid:
        return

    try:
        i = supabase.table("incidencia").select("*").eq("incidenciaid", incidenciaid).single().execute().data
    except Exception as e:
        st.error(f"❌ Error cargando incidencia: {e}")
        return

    trabajadores = load_trabajadores(supabase)
    estado = i.get("estado", "Abierta")
    trabajador_lbl = _label(trabajadores, i.get("responsableid"))

    color = "#9ca3af"
    if "abier" in estado.lower(): color = "#f59e0b"
    elif "curso" in estado.lower(): color = "#3b82f6"
    elif "solu" in estado.lower() or "cerr" in estado.lower(): color = "#10b981"
    elif "rech" in estado.lower(): color = "#ef4444"

    st.markdown("---")
    st.markdown(f"### 🧾 Detalle de incidencia #{incidenciaid}")
    st.markdown(
        f"<div style='background:{color};color:#fff;padding:5px 10px;border-radius:8px;width:fit-content;'>{estado}</div>",
        unsafe_allow_html=True,
    )
    st.markdown(f"**Tipo:** {i.get('tipo','-')} ({i.get('origen_tipo','-')})")
    st.markdown(f"**Descripción:** {i.get('descripcion','_Sin descripción_')}")
    st.markdown(f"**Responsable:** {trabajador_lbl or '-'}")
    st.markdown(f"**Prioridad:** {i.get('prioridad','-')}")
    st.markdown(f"**Fecha creación:** {i.get('fecha_creacion','-')}")

    if i.get("resolucion"):
        st.markdown("### ✅ Resolución")
        st.write(i["resolucion"])

    # --- Edición rápida
    st.markdown("---")
    st.subheader("✏️ Editar incidencia")

    col1, col2, col3 = st.columns(3)
    with col1:
        nuevo_estado = st.selectbox("Estado", ["Abierta", "En curso", "Solucionada", "Rechazada"], index=_estado_idx(estado))
    with col2:
        nuevo_asignado = st.selectbox("Responsable", ["(Sin asignar)"] + list(trabajadores.keys()))
    with col3:
        prioridad = st.selectbox("Prioridad", ["Baja", "Media", "Alta"], index=_prio_index(i.get("prioridad")))

    resolucion_text = ""
    fecha_resolucion = i.get("fecha_resolucion")
    if "solu" in nuevo_estado.lower() and not i.get("resolucion"):
        resolucion_text = st.text_area("✍️ Añade resolución", value=i.get("resolucion") or "")
        if not fecha_resolucion:
            fecha_resolucion = datetime.now().isoformat(timespec="seconds")

    if st.button("💾 Guardar cambios", use_container_width=True):
        try:
            payload = {
                "estado": nuevo_estado,
                "responsableid": trabajadores.get(nuevo_asignado) if nuevo_asignado != "(Sin asignar)" else None,
                "prioridad": prioridad,
            }
            if resolucion_text:
                payload["resolucion"] = resolucion_text.strip()
                payload["fecha_resolucion"] = fecha_resolucion

            supabase.table("incidencia").update(payload).eq("incidenciaid", incidenciaid).execute()
            st.success("✅ Cambios guardados correctamente.")
            st.session_state["inci_show_modal"] = False
            st.session_state["inci_detalle_id"] = None
            st.rerun()
        except Exception as e:
            st.error(f"❌ Error guardando cambios: {e}")

    st.markdown("---")
    if st.button("⬅️ Volver al listado", use_container_width=True):
        st.session_state["inci_show_modal"] = False
        st.session_state["inci_detalle_id"] = None
        st.rerun()


# ======================================================
# 🔧 HELPERS EXTRA
# ======================================================
def _estado_idx(e):
    e = (e or "").lower()
    if "curso" in e: return 1
    if "solu" in e: return 2
    if "rech" in e: return 3
    return 0

def _prio_index(p):
    if not p:
        return 1
    p = p.lower()
    if "baj" in p:
        return 0
    if "alt" in p:
        return 2
    return 1
