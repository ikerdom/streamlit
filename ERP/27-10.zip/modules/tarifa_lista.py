# modules/tarifa_lista.py
import streamlit as st
import pandas as pd
from datetime import date

def render_tarifa_lista(supabase):
    st.header("🏷️ Tarifas y reglas")
    st.caption("Define tarifas, sus reglas y las asignaciones por cliente (tramos).")

    tabs = st.tabs(["🧾 Tarifas", "🧩 Reglas", "👤 Asignaciones cliente"])

    # ---- Tarifas (cabecera)
    with tabs[0]:
        with st.expander("➕ Nueva tarifa", expanded=False):
            with st.form("form_tarifa_new"):
                col1, col2, col3 = st.columns([2,1,1])
                with col1:
                    nombre = st.text_input("Nombre", placeholder="Tarifa General 2025")
                with col2:
                    fd = st.date_input("Desde", value=date.today())
                with col3:
                    fh = st.date_input("Hasta (opcional)", value=None)
                ok = st.form_submit_button("Guardar")
            if ok:
                try:
                    payload = {"nombre": nombre.strip(), "fecha_desde": fd.isoformat(), "fecha_hasta": fh.isoformat() if fh else None, "habilitada": True}
                    supabase.table("tarifa").insert(payload).execute()
                    st.success("✅ Tarifa creada.")
                    st.rerun()
                except Exception as e:
                    st.error(f"❌ Error creando tarifa: {e}")

        try:
            t = supabase.table("tarifa").select("*").order("tarifaid").execute().data or []
            st.dataframe(pd.DataFrame(t), use_container_width=True)
        except Exception as e:
            st.error(f"❌ Error cargando tarifas: {e}")

    # ---- Reglas
    with tabs[1]:
        # selector de tarifa
        try:
            t = supabase.table("tarifa").select("tarifaid, nombre").order("tarifaid").execute().data or []
        except Exception as e:
            st.error(f"❌ Error cargando tarifas: {e}")
            t = []
        mapa_t = {f"{r['tarifaid']} · {r['nombre']}": r["tarifaid"] for r in t}
        sel = st.selectbox("Tarifa", list(mapa_t.keys())) if mapa_t else None
        tarifaid = mapa_t.get(sel) if sel else None

        with st.expander("➕ Nueva regla", expanded=False):
            with st.form("form_regla_new"):
                col1, col2, col3 = st.columns([1,1,1])
                with col1:
                    tipo_aplic = st.selectbox("Tipo aplicación", ["producto","familia","cliente"])
                with col2:
                    tipo_desc = st.selectbox("Tipo descuento", ["porcentaje","fijo"])
                with col3:
                    valor = st.number_input("Valor", min_value=0.0, step=0.01)

                col4, col5, col6 = st.columns([1,1,1])
                with col4: productoid = st.number_input("productoid", min_value=0, value=0, step=1)
                with col5: familiaid = st.number_input("familiaid", min_value=0, value=0, step=1)
                with col6: clienteid = st.number_input("clienteid", min_value=0, value=0, step=1)

                col7, col8, col9 = st.columns([1,1,1])
                with col7: prioridad = st.number_input("Prioridad", min_value=1, value=100, step=1)
                with col8: fd = st.date_input("Desde", value=date.today())
                with col9: fh = st.date_input("Hasta (opcional)", value=None)

                ok = st.form_submit_button("Guardar regla", disabled=not bool(tarifaid))
            if ok and tarifaid:
                try:
                    payload = {
                        "tarifaid": tarifaid,
                        "tipo_aplicacion": tipo_aplic,
                        "productoid": productoid or None,
                        "familiaid": familiaid or None,
                        "clienteid": clienteid or None,
                        "tipo_descuento": tipo_desc,
                        "valor": valor,
                        "prioridad": int(prioridad),
                        "fecha_desde": fd.isoformat(),
                        "fecha_hasta": fh.isoformat() if fh else None,
                        "habilitada": True,
                    }
                    supabase.table("tarifa_regla").insert(payload).execute()
                    st.success("✅ Regla creada.")
                    st.rerun()
                except Exception as e:
                    st.error(f"❌ Error creando regla: {e}")

        if tarifaid:
            try:
                r = (supabase.table("tarifa_regla")
                     .select("*")
                     .eq("tarifaid", tarifaid)
                     .order("prioridad")
                     .execute().data or [])
                st.dataframe(pd.DataFrame(r), use_container_width=True)
            except Exception as e:
                st.error(f"❌ Error cargando reglas: {e}")

    # ---- Asignaciones cliente
    with tabs[2]:
        with st.expander("➕ Asignar tarifa a cliente", expanded=False):
            with st.form("form_cli_tarifa_new"):
                col1, col2, col3 = st.columns([1,1,1])
                with col1: clienteid = st.number_input("clienteid", min_value=1, step=1)
                with col2:
                    try:
                        t = supabase.table("tarifa").select("tarifaid, nombre").order("tarifaid").execute().data or []
                    except Exception as e:
                        st.error(f"❌ Error cargando tarifas: {e}")
                        t = []
                    mapa_t2 = {f"{r['tarifaid']} · {r['nombre']}": r["tarifaid"] for r in t}
                    key = st.selectbox("Tarifa", list(mapa_t2.keys())) if mapa_t2 else None
                    tarifaid2 = mapa_t2.get(key) if key else None
                with col3:
                    fd = st.date_input("Desde", value=date.today())
                fh = st.date_input("Hasta (opcional)", value=None)
                ok = st.form_submit_button("Asignar", disabled=not bool(tarifaid2))
            if ok and tarifaid2:
                try:
                    payload = {
                        "clienteid": int(clienteid),
                        "tarifaid": int(tarifaid2),
                        "fecha_desde": fd.isoformat(),
                        "fecha_hasta": fh.isoformat() if fh else None,
                    }
                    supabase.table("cliente_tarifa").insert(payload).execute()
                    st.success("✅ Asignación creada.")
                    st.rerun()
                except Exception as e:
                    st.error(f"❌ Error creando asignación: {e}")

        try:
            rows = (supabase.table("cliente_tarifa")
                    .select("*")
                    .order("cliente_tarifaid", desc=True)
                    .limit(200)
                    .execute().data or [])
            st.dataframe(pd.DataFrame(rows), use_container_width=True)
        except Exception as e:
            st.error(f"❌ Error cargando asignaciones: {e}")
