# ======================================================
# 🧾 FORMULARIO DE PRESUPUESTO — Alta y edición
# ======================================================
import streamlit as st
from datetime import date
from modules.pedido_models import load_clientes, load_trabajadores

def _load_estados_presupuesto(supabase) -> dict:
    try:
        rows = supabase.table("estado_presupuesto").select("estado_presupuestoid, nombre").order("estado_presupuestoid").execute().data or []
        return {r["nombre"]: r["estado_presupuestoid"] for r in rows}
    except Exception:
        return {}

def render_presupuesto_form(supabase, presupuestoid=None, bloqueado=False, on_saved_rerun=True):
    """✏️ Crear / editar presupuesto."""
    st.subheader("🧾 Presupuesto")

    clientes = load_clientes(supabase)
    trabajadores = load_trabajadores(supabase)
    estados = _load_estados_presupuesto(supabase)

    presupuesto = {}
    if presupuestoid:
        try:
            r = supabase.table("presupuesto").select("*").eq("presupuestoid", presupuestoid).single().execute()
            presupuesto = r.data or {}
        except Exception as e:
            st.error(f"❌ Error cargando presupuesto: {e}")

    def _index(d, val):
        keys = list(d.keys())
        for i, k in enumerate(keys):
            if d[k] == val:
                return i + 1
        return 0

    with st.expander("✏️ Datos del presupuesto", expanded=True):
        with st.form(f"form_presupuesto_{presupuestoid or 'new'}"):
            c1, c2 = st.columns(2)
            with c1:
                cliente_sel = st.selectbox("Cliente", ["(sin cliente)"] + list(clientes.keys()),
                                           index=_index(clientes, presupuesto.get("clienteid")),
                                           disabled=bloqueado)
            with c2:
                trab_sel = st.selectbox("Comercial", ["(sin comercial)"] + list(trabajadores.keys()),
                                        index=_index(trabajadores, presupuesto.get("trabajadorid")),
                                        disabled=bloqueado)

            numero = st.text_input("Número", presupuesto.get("numero", ""), disabled=bloqueado)
            referencia = st.text_input("Referencia cliente", presupuesto.get("referencia_cliente", ""), disabled=bloqueado)
            fecha = st.date_input("Fecha", value=date.fromisoformat(presupuesto["fecha_presupuesto"]) if presupuesto.get("fecha_presupuesto") else date.today(), disabled=bloqueado)
            total = st.number_input("Total estimado (€)", min_value=0.0, step=0.01, value=float(presupuesto.get("total_estimada") or 0), disabled=bloqueado)
            observaciones = st.text_area("Observaciones", presupuesto.get("observaciones", ""), height=100, disabled=bloqueado)

            estado_sel = st.selectbox("Estado", list(estados.keys()),
                                      index=(list(estados.values()).index(presupuesto.get("estado_presupuestoid")) if presupuesto.get("estado_presupuestoid") in estados.values() else 0),
                                      disabled=bloqueado)
            facturar = st.checkbox("Facturar individualmente", value=bool(presupuesto.get("facturar_individual", False)), disabled=bloqueado)
            enviar = st.form_submit_button("💾 Guardar presupuesto", disabled=bloqueado, use_container_width=True)

        if enviar:
            payload = {
                "numero": numero.strip(),
                "clienteid": clientes.get(cliente_sel),
                "trabajadorid": trabajadores.get(trab_sel),
                "referencia_cliente": referencia.strip() or None,
                "fecha_presupuesto": fecha.isoformat(),
                "observaciones": observaciones.strip() or None,
                "total_estimada": float(total),
                "facturar_individual": facturar,
                "estado_presupuestoid": estados.get(estado_sel),
            }
            try:
                if presupuestoid:
                    supabase.table("presupuesto").update(payload).eq("presupuestoid", presupuestoid).execute()
                    st.toast("✅ Presupuesto actualizado.", icon="✅")
                else:
                    supabase.table("presupuesto").insert(payload).execute()
                    st.toast("✅ Presupuesto creado correctamente.", icon="✅")
                if on_saved_rerun:
                    st.rerun()
            except Exception as e:
                st.error(f"❌ Error guardando presupuesto: {e}")
