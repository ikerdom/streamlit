import streamlit as st
import pandas as pd
from datetime import datetime

def render_presupuesto_detalle(supabase, presupuestoid: int, bloqueado: bool = False):
    """
    📦 Detalle de líneas del presupuesto (tabla + alta rápida).
    - bloqueado=True deshabilita la edición (para Aceptado / Convertido).
    """
    st.subheader("📦 Detalle de productos del presupuesto")

    # =========================
    # Cargar líneas
    # =========================
    try:
        res = (
            supabase.table("presupuesto_detalle")
            .select("presupuesto_detalleid, productoid, descripcion, cantidad, precio_unitario, descuento_pct, total_linea")
            .eq("presupuestoid", presupuestoid)
            .order("presupuesto_detalleid", desc=False)   # ✅ corrección: desc=False
            .execute()
        )
        lineas = res.data or []
    except Exception as e:
        st.error(f"❌ Error cargando líneas del presupuesto: {e}")
        return

    # =========================
    # Tabla
    # =========================
    if not lineas:
        st.info("📭 No hay líneas en este presupuesto todavía.")
    else:
        df = pd.DataFrame(lineas)
        if "total_linea" in df.columns:
            df["total_linea"] = df.apply(
                lambda r: float(r.get("total_linea") or 0.0)
                if r.get("total_linea") not in (None, "")
                else float(r.get("cantidad") or 0.0) * float(r.get("precio_unitario") or 0.0) * (1 - float(r.get("descuento_pct") or 0.0) / 100.0),
                axis=1,
            )
        st.dataframe(df, use_container_width=True)

    st.divider()

    # =========================
    # Alta rápida
    # =========================
    st.markdown("### ➕ Añadir nueva línea")
    if bloqueado:
        st.info("🔒 Este presupuesto está bloqueado y no permite añadir ni modificar líneas.")
        return

    with st.form(f"form_linea_presupuesto_{presupuestoid}"):
        col1, col2, col3 = st.columns([3, 1, 1])
        with col1:
            descripcion = st.text_input("Descripción del producto o servicio")
        with col2:
            cantidad = st.number_input("Cantidad", min_value=1.0, step=1.0, value=1.0)
        with col3:
            precio = st.number_input("Precio unitario (€)", min_value=0.0, step=0.1, value=0.0)

        col4, col5 = st.columns(2)
        with col4:
            descuento = st.number_input("Descuento (%)", min_value=0.0, max_value=100.0, step=0.5, value=0.0)
        with col5:
            total_linea = (cantidad * precio) * (1 - descuento / 100.0)
            st.metric("Importe total línea (€)", f"{total_linea:.2f}")

        enviar = st.form_submit_button("💾 Añadir línea")

    if enviar:
        if not (descripcion or "").strip():
            st.warning("⚠️ La descripción es obligatoria.")
            return
        try:
            payload = {
                "presupuestoid": presupuestoid,
                "descripcion": descripcion.strip(),
                "cantidad": float(cantidad),
                "precio_unitario": float(precio),
                "descuento_pct": float(descuento),
                "total_linea": float(total_linea),
                "fecha_alta": datetime.now().isoformat(timespec="seconds"),
            }
            supabase.table("presupuesto_detalle").insert(payload).execute()
            st.success("✅ Línea añadida correctamente.")
            st.rerun()
        except Exception as e:
            st.error(f"❌ Error al insertar línea: {e}")
