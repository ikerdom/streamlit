import streamlit as st

# ======================================================
# 🧩 FORM · Direcciones del cliente (fiscal + envío)
# ======================================================

def render_direccion_form(supabase, clienteid, modo="cliente"):
    """Gestiona las direcciones fiscales y de envío de un cliente."""
    st.markdown("### 🏠 Direcciones del cliente")
    st.caption("Gestiona la dirección fiscal (única) y las direcciones de envío (múltiples).")

    try:
        res = (
            supabase.table("cliente_direccion")
            .select("*")
            .eq("clienteid", int(clienteid))
            .order("tipo")
            .execute()
        )
        direcciones = res.data or []
    except Exception as e:
        st.error(f"❌ No se pudieron cargar las direcciones: {e}")
        return

    dir_fiscal = [d for d in direcciones if d.get("tipo") == "fiscal"]
    dir_envio = [d for d in direcciones if d.get("tipo") == "envio"]

    # ==========================================================
    # 🧾 DIRECCIÓN FISCAL (única)
    # ==========================================================
    st.markdown("#### 🧾 Dirección fiscal")
    if dir_fiscal:
        d = dir_fiscal[0]
        with st.expander(
            f"📍 {d.get('direccion','(Sin dirección)')} — {d.get('ciudad','')}",
            expanded=False,
        ):
            _direccion_editor(supabase, clienteid, d, tipo="fiscal", modo=modo)
    else:
        with st.expander("➕ Añadir dirección fiscal", expanded=False):
            _direccion_editor(supabase, clienteid, None, tipo="fiscal", modo=modo)

    # ==========================================================
    # 🚚 DIRECCIONES DE ENVÍO
    # ==========================================================
    st.markdown("---")
    st.markdown("#### 🚚 Direcciones de envío")
    if not dir_envio and dir_fiscal:
        st.info("📦 No hay direcciones de envío. Se usará la fiscal como predeterminada.")

    for d in dir_envio:
        key_suffix = f"{clienteid}_{d.get('cliente_direccionid')}"
        with st.expander(
            f"📦 {d.get('direccion','(Sin dirección)')} — {d.get('ciudad','')}",
            expanded=False,
        ):
            _direccion_editor(supabase, clienteid, d, tipo="envio", modo=modo, unique_key=key_suffix)

    if st.button("➕ Añadir nueva dirección de envío", key=f"add_envio_btn_{clienteid}", use_container_width=True):
        st.session_state[f"show_new_envio_{clienteid}"] = not st.session_state.get(f"show_new_envio_{clienteid}", False)

    if st.session_state.get(f"show_new_envio_{clienteid}"):
        with st.expander("➕ Nueva dirección de envío", expanded=True):
            _direccion_editor(supabase, clienteid, None, tipo="envio", modo=modo, unique_key=f"{clienteid}_new")


# ======================================================
# 🔧 Editor interno de dirección
# ======================================================
def _direccion_editor(supabase, clienteid, d, tipo="envio", modo="cliente", unique_key=""):
    is_new = d is None
    dirid = (d or {}).get("cliente_direccionid")
    prefix = f"{tipo}_{clienteid}_{dirid or 'new'}_{unique_key}"

    def _field(key, label, default=""):
        full_key = f"{prefix}_{key}"
        st.session_state.setdefault(full_key, (d or {}).get(key, default))
        return st.text_input(label, value=st.session_state[full_key], key=full_key)

    # Campos principales
    direccion = _field("direccion", "Dirección completa")
    ciudad = _field("ciudad", "Ciudad")
    provincia = _field("provincia", "Provincia")
    cp = _field("cp", "Código postal")
    pais = _field("pais", "País", "España")
    telefono = _field("telefono", "Teléfono")
    email = _field("email", "Email")

    c1, c2, c3 = st.columns([1, 1, 1])

    with c1:
        if st.button("💾 Guardar", key=f"{prefix}_save", use_container_width=True):
            direccion_val = direccion.strip()
            ciudad_val = ciudad.strip()
            if not direccion_val or not ciudad_val:
                st.warning("⚠️ Dirección y ciudad son obligatorias.")
                return

            data = {
                "clienteid": int(clienteid),
                "tipo": tipo,
                "direccion": direccion_val,
                "ciudad": ciudad_val,
                "provincia": provincia.strip(),
                "cp": cp.strip(),
                "pais": pais.strip(),
                "telefono": telefono.strip(),
                "email": email.strip(),
            }

            try:
                if is_new:
                    supabase.table("cliente_direccion").insert(data).execute()
                    st.toast("✅ Dirección añadida correctamente.", icon="✅")
                else:
                    supabase.table("cliente_direccion").update(data).eq("cliente_direccionid", dirid).execute()
                    st.toast("✅ Dirección actualizada correctamente.", icon="✅")
                st.session_state[f"show_new_envio_{clienteid}"] = False
                st.rerun()
            except Exception as e:
                st.error(f"❌ Error al guardar dirección: {e}")

    with c2:
        if not is_new and st.button("🗑️ Eliminar", key=f"{prefix}_delete", use_container_width=True):
            try:
                supabase.table("cliente_direccion").delete().eq("cliente_direccionid", dirid).execute()
                st.toast("🗑️ Dirección eliminada correctamente.", icon="🗑️")
                st.rerun()
            except Exception as e:
                st.error(f"❌ Error al eliminar dirección: {e}")

    with c3:
        if not is_new and tipo == "envio":
            if st.button("⭐ Principal", key=f"{prefix}_main", use_container_width=True):
                try:
                    supabase.table("cliente_direccion").update({"es_principal": False}).eq("clienteid", clienteid).eq("tipo", "envio").execute()
                    supabase.table("cliente_direccion").update({"es_principal": True}).eq("cliente_direccionid", dirid).execute()
                    st.toast("⭐ Marcada como principal.", icon="⭐")
                    st.rerun()
                except Exception as e:
                    st.error(f"❌ Error al marcar principal: {e}")
