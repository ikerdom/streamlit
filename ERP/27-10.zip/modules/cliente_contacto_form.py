import streamlit as st

# =========================================================
# 👥 FORM · Contactos del cliente
# =========================================================

def render_contacto_form(supabase, clienteid: int):
    """Gestión de contactos asociados a un cliente."""
    st.markdown("### 👥 Contactos del cliente")
    st.caption("Consulta, añade o edita los contactos asociados a este cliente.")

    # =====================================================
    # 📦 Cargar contactos
    # =====================================================
    try:
        res = (
            supabase.table("cliente_contacto")
            .select("*")
            .eq("clienteid", int(clienteid))
            .order("es_principal", desc=True)
            .order("nombre")
            .execute()
        )
        contactos = res.data or []
    except Exception as e:
        st.error(f"❌ No se pudieron cargar los contactos: {e}")
        return

    # =====================================================
    # ➕ Añadir nuevo contacto
    # =====================================================
    with st.expander("➕ Añadir nuevo contacto", expanded=False):
        _contacto_editor(supabase, clienteid, None)

    # =====================================================
    # 📇 Listado de contactos existentes
    # =====================================================
    if not contactos:
        st.info("📭 Este cliente no tiene contactos registrados.")
        return

    st.markdown("---")
    for c in contactos:
        nombre = c.get("nombre", "(Sin nombre)")
        cargo = c.get("cargo", "")
        email = ", ".join(eval(c["email"])) if isinstance(c.get("email"), str) and c["email"].startswith("{") else c.get("email", "")
        telefono = ", ".join(eval(c["telefono"])) if isinstance(c.get("telefono"), str) and c["telefono"].startswith("{") else c.get("telefono", "")
        rol = c.get("rol", "")
        obs = c.get("observaciones", "")
        es_principal = c.get("es_principal", False)

        color_fondo = "#eef2ff" if es_principal else "#f9fafb"
        borde = "#6366f1" if es_principal else "#e5e7eb"

        with st.container():
            st.markdown(
                f"""
                <div style="border:1px solid {borde};
                            border-radius:10px;
                            padding:12px;
                            margin-bottom:10px;
                            background:{color_fondo};">
                    <b>{nombre}</b> <span style='color:#6b7280;'>({cargo or "Sin cargo"})</span><br>
                    📧 <b>Email:</b> {email or "-"}<br>
                    ☎️ <b>Teléfono:</b> {telefono or "-"}<br>
                    🧩 <b>Rol:</b> {rol or "-"}<br>
                    📝 <b>Notas:</b> {obs or "-"}
                </div>
                """,
                unsafe_allow_html=True,
            )

            col1, col2, col3 = st.columns([1, 1, 1])
            with col1:
                if st.button("✏️ Editar", key=f"edit_contact_{c['cliente_contactoid']}", use_container_width=True):
                    st.session_state[f"edit_contact_{c['cliente_contactoid']}"] = not st.session_state.get(f"edit_contact_{c['cliente_contactoid']}", False)

            with col2:
                if st.button("🗑️ Eliminar", key=f"delete_contact_{c['cliente_contactoid']}", use_container_width=True):
                    try:
                        supabase.table("cliente_contacto").delete().eq("cliente_contactoid", c["cliente_contactoid"]).execute()
                        st.toast("🗑️ Contacto eliminado correctamente.", icon="🗑️")
                        st.rerun()
                    except Exception as e:
                        st.error(f"❌ Error al eliminar contacto: {e}")

            with col3:
                if not es_principal:
                    if st.button("⭐ Principal", key=f"main_contact_{c['cliente_contactoid']}", use_container_width=True):
                        try:
                            supabase.table("cliente_contacto").update({"es_principal": False}).eq("clienteid", clienteid).execute()
                            supabase.table("cliente_contacto").update({"es_principal": True}).eq("cliente_contactoid", c["cliente_contactoid"]).execute()
                            st.toast("⭐ Contacto marcado como principal.", icon="⭐")
                            st.rerun()
                        except Exception as e:
                            st.error(f"❌ Error al marcar contacto principal: {e}")

            # -------------------------------------------------
            # ✏️ Expander edición
            # -------------------------------------------------
            if st.session_state.get(f"edit_contact_{c['cliente_contactoid']}"):
                with st.expander(f"✏️ Editar contacto — {nombre}", expanded=True):
                    _contacto_editor(supabase, clienteid, c)


# =========================================================
# 🔧 Editor interno de contacto (alta / edición)
# =========================================================
def _contacto_editor(supabase, clienteid, c=None):
    """Formulario de creación o edición de contacto."""
    is_new = c is None
    cid = (c or {}).get("cliente_contactoid")
    prefix = f"contact_{cid or 'new'}"

    def _field(key, label, default=""):
        full_key = f"{prefix}_{key}"
        st.session_state.setdefault(full_key, (c or {}).get(key, default))
        return st.text_input(label, value=st.session_state[full_key], key=full_key)

    nombre = _field("nombre", "Nombre *")
    cargo = _field("cargo", "Cargo / Puesto")
    rol = _field("rol", "Rol interno o comercial")
    email = _field("email", "Email")
    telefono = _field("telefono", "Teléfono")
    direccion = _field("direccion", "Dirección")
    ciudad = _field("ciudad", "Ciudad")
    provincia = _field("provincia", "Provincia")
    pais = _field("pais", "País", "España")
    observaciones = st.text_area("Observaciones", value=(c or {}).get("observaciones", ""), key=f"{prefix}_obs")

    col1, col2 = st.columns([1, 1])

    with col1:
        if st.button("💾 Guardar", key=f"{prefix}_save", use_container_width=True):
            if not nombre.strip():
                st.warning("⚠️ El nombre es obligatorio.")
                return

            data = {
                "clienteid": int(clienteid),
                "nombre": nombre.strip(),
                "cargo": cargo.strip() or None,
                "rol": rol.strip() or None,
                "email": email.strip() or None,
                "telefono": telefono.strip() or None,
                "direccion": direccion.strip() or None,
                "ciudad": ciudad.strip() or None,
                "provincia": provincia.strip() or None,
                "pais": pais.strip() or None,
                "observaciones": observaciones.strip() or None,
            }

            try:
                if is_new:
                    supabase.table("cliente_contacto").insert(data).execute()
                    st.toast("✅ Contacto añadido correctamente.", icon="✅")
                else:
                    supabase.table("cliente_contacto").update(data).eq("cliente_contactoid", cid).execute()
                    st.toast("✅ Contacto actualizado correctamente.", icon="✅")
                st.rerun()
            except Exception as e:
                st.error(f"❌ Error al guardar contacto: {e}")

    with col2:
        if not is_new:
            if st.button("🗑️ Eliminar", key=f"{prefix}_delete", use_container_width=True):
                try:
                    supabase.table("cliente_contacto").delete().eq("cliente_contactoid", cid).execute()
                    st.toast("🗑️ Contacto eliminado correctamente.", icon="🗑️")
                    st.rerun()
                except Exception as e:
                    st.error(f"❌ Error al eliminar contacto: {e}")
