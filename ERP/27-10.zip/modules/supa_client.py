from supabase import create_client

SUPABASE_URL = "https://gqhrbvusvcaytcbnusdx.supabase.co"
SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImdxaHJidnVzdmNheXRjYm51c2R4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTk0MzM3MDQsImV4cCI6MjA3NTAwOTcwNH0.y3018JLs9A08sSZKHLXeMsITZ3oc4s2NDhNLxWqM9Ag"

def get_supabase_client():
    """Devuelve un único cliente compartido en toda la app."""
    from streamlit import session_state as st
    if "supabase" not in st:
        st.supabase = create_client(SUPABASE_URL, SUPABASE_KEY)
    return st.supabase
