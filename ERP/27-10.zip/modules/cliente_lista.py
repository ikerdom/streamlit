import io
import math
import pandas as pd
import streamlit as st
from datetime import date

from modules.cliente_models import (
    load_estados_cliente,
    load_categorias,
    load_grupos,
    load_trabajadores,
    load_formas_pago,
    get_estado_label,
    get_categoria_label,
    get_grupo_label,
    get_trabajador_label,
    get_formapago_label,
)

# Formularios
from modules.cliente_direccion_form import render_direccion_form
from modules.cliente_facturacion_form import render_facturacion_form
from modules.cliente_observacion_form import render_observaciones_form
from modules.cliente_crm_form import render_crm_form
from modules.cliente_documento_form import render_documento_form


# =========================================================
# 🔧 Utils
# =========================================================
def _safe(v, d="-"):
    return v if v not in (None, "", "null") else d


def _range(page: int, page_size: int):
    start = (page - 1) * page_size
    end = start + page_size - 1
    return start, end


def _build_search_or(s, fields=("razon_social", "identificador")):
    s = (s or "").strip()
    if not s:
        return None
    return ",".join([f"{f}.ilike.%{s}%" for f in fields])


# =========================================================
# 🧭 Vista principal
# =========================================================
def render_cliente_lista(supabase):
    st.header("🏢 Gestión de clientes")
    st.caption("Visualiza, filtra y gestiona los clientes activos junto con su historial de presupuestos.")

    # Estado UI
    defaults = {
        "cli_page": 1,
        "cli_view": "Tarjetas",
        "cli_sort": "razon_social ASC",
        "show_cliente_modal": False,
        "cliente_modal_id": None,
        "confirm_delete": False,
    }
    for k, v in defaults.items():
        st.session_state.setdefault(k, v)

    page_size_cards = 12
    page_size_table = 30

    # Catálogos
    estados = load_estados_cliente(supabase)
    categorias = load_categorias(supabase)
    grupos = load_grupos(supabase)
    trabajadores = load_trabajadores(supabase)
    fpagos = load_formas_pago(supabase)

    # ---------------------------------------------------------
    # 🎛️ Filtros
    # ---------------------------------------------------------
    with st.expander("🔍 Filtros de búsqueda y orden", expanded=True):
        c1, c2, c3, c4 = st.columns([2, 2, 2, 1])
        with c1:
            q = st.text_input("Buscar cliente", placeholder="Razón social o identificador…", key="cli_q")
        with c2:
            estado_sel = st.selectbox("Estado", ["Todos"] + list(estados.keys()), key="cli_estado")
        with c3:
            categoria_sel = st.selectbox("Categoría", ["Todas"] + list(categorias.keys()), key="cli_categoria")
        with c4:
            view = st.radio("Vista", ["Tarjetas", "Tabla"], horizontal=True, key="cli_view")

        c5, c6, c7, c8 = st.columns([2, 2, 2, 2])
        with c5:
            grupo_sel = st.selectbox("Grupo", ["Todos"] + list(grupos.keys()), key="cli_grupo")
        with c6:
            trab_sel = st.selectbox("Trabajador", ["Todos"] + list(trabajadores.keys()), key="cli_trab")
        with c7:
            fpago_sel = st.selectbox("Forma de pago", ["Todas"] + list(fpagos.keys()), key="cli_fpago")
        with c8:
            presup_sel = st.selectbox("Presupuesto", ["Todos", "Pendiente", "Aceptado", "Rechazado", "Sin presupuesto"], key="cli_presup")

    # ---------------------------------------------------------
    # 📊 Query principal
    # ---------------------------------------------------------
    total = 0
    clientes = []

    try:
        base = supabase.table("cliente").select(
            "clienteid, razon_social, identificador, estadoid, categoriaid, grupoid, trabajadorid, formapagoid"
        ).eq("tipo_cliente", "cliente")

        or_filter = _build_search_or(q)
        if or_filter:
            base = base.or_(or_filter)

        if estado_sel != "Todos" and estado_sel in estados:
            base = base.eq("estadoid", estados[estado_sel])
        if categoria_sel != "Todas" and categoria_sel in categorias:
            base = base.eq("categoriaid", categorias[categoria_sel])
        if grupo_sel != "Todos" and grupo_sel in grupos:
            base = base.eq("grupoid", grupos[grupo_sel])
        if trab_sel != "Todos" and trab_sel in trabajadores:
            base = base.eq("trabajadorid", trabajadores[trab_sel])
        if fpago_sel != "Todas" and fpago_sel in fpagos:
            base = base.eq("formapagoid", fpagos[fpago_sel])

        # Orden
        field, direction = st.session_state.cli_sort.split(" ")
        base = base.order(field, desc=(direction.upper() == "DESC"))

        data = base.execute()
        clientes = data.data or []
        total = len(clientes)
    except Exception as e:
        st.error(f"❌ Error cargando clientes: {e}")

    # ---------------------------------------------------------
    # 🧾 Resumen rápido
    # ---------------------------------------------------------
    st.markdown("---")
    col_kpi1, col_kpi2, col_kpi3 = st.columns(3)
    with col_kpi1:
        st.metric("Total clientes", total)
    with col_kpi2:
        st.metric("Vista actual", view)
    with col_kpi3:
        st.metric("Orden", st.session_state.cli_sort)

    # ---------------------------------------------------------
    # 📋 Resultados
    # ---------------------------------------------------------
    if not clientes:
        st.info("📭 No hay clientes que coincidan con los filtros.")
        return

    st.caption(f"Mostrando {total} clientes.")
    st.markdown("---")

    if view == "Tarjetas":
        cols = st.columns(3)
        for i, c in enumerate(clientes):
            with cols[i % 3]:
                _render_card(c, supabase)
    else:
        _render_table(clientes, supabase)

    # Modal de ficha
    if st.session_state.get("show_cliente_modal"):
        render_cliente_modal(supabase)


# =========================================================
# 💳 Tarjeta de cliente
# =========================================================
def _render_card(c, supabase):
    razon = _safe(c.get("razon_social"))
    ident = _safe(c.get("identificador"))
    estado = get_estado_label(c.get("estadoid"), supabase)
    categoria = get_categoria_label(c.get("categoriaid"), supabase)
    grupo = get_grupo_label(c.get("grupoid"), supabase)
    trabajador = get_trabajador_label(c.get("trabajadorid"), supabase)
    forma_pago = get_formapago_label(c.get("formapagoid"), supabase)

    # Consultar último presupuesto
    try:
        pres = (
            supabase.table("presupuesto")
            .select("estado_presupuestoid, fecha_presupuesto")
            .eq("clienteid", c["clienteid"])
            .order("fecha_presupuesto", desc=True)
            .limit(1)
            .execute()
        )
        pres_estadoid = pres.data[0]["estado_presupuestoid"] if pres.data else None
        pres_fecha = pres.data[0]["fecha_presupuesto"] if pres.data else None

        # Map simple para traducir ID a nombre visual
        estado_map = {1: "Pendiente", 2: "Aceptado", 3: "Rechazado"}
        pres_estado = estado_map.get(pres_estadoid, "Sin presupuesto")
    except Exception:
        pres_estado, pres_fecha = None, None

    # Formato visual
    colores = {
        "Aceptado": "#16a34a",
        "Rechazado": "#dc2626",
        "Pendiente": "#f59e0b",
        "Sin presupuesto": "#6b7280",
    }
    color = colores.get(pres_estado, "#6b7280")

    ultima = (
        f"<div style='color:#4b5563;font-size:0.85rem;'>🗓️ Último presupuesto aceptado: {pres_fecha}</div>"
        if pres_estado == "Aceptado"
        else ""
    )

    st.markdown(
        f"""
        <div style="border:1px solid #e5e7eb;border-radius:12px;padding:12px;margin-bottom:10px;
                    background:#f9fafb;box-shadow:0 1px 2px rgba(0,0,0,0.05);
                    transition:all 0.2s ease-in-out;">
            <b>{razon}</b> <span style="color:#6b7280;">({ident})</span><br>
            🏷️ <b>Estado:</b> {estado}<br>
            🧩 <b>Categoría:</b> {categoria}<br>
            👥 <b>Grupo:</b> {grupo}<br>
            💳 <b>Forma de pago:</b> {forma_pago}<br>
            🧑 <b>Trabajador:</b> {trabajador}<br>
            <span style="color:{color};font-weight:600;">📦 {pres_estado}</span><br>{ultima}
        </div>
        """,
        unsafe_allow_html=True,
    )

    a, b, ccol = st.columns([1, 1, 1])
    with a:
        if st.button("📄 Ficha", key=f"ficha_cli_{c['clienteid']}", use_container_width=True):
            st.session_state.update({
                "cliente_modal_id": c["clienteid"],
                "show_cliente_modal": True,
                "confirm_delete": False,
            })
            st.rerun()

    with b:
        if st.button("📨 Nuevo presupuesto", key=f"pres_cli_{c['clienteid']}", use_container_width=True):
            try:
                supabase.table("presupuesto").insert({
                    "numero": f"PRES-{date.today().year}-{c['clienteid']}",
                    "clienteid": c["clienteid"],
                    "trabajadorid": c.get("trabajadorid"),
                    "estado_presupuestoid": 1,  # Pendiente
                    "fecha_presupuesto": date.today().isoformat(),
                    "observaciones": "Presupuesto inicial creado desde la ficha del cliente.",
                    "editable": True,
                    "facturar_individual": False,
                }).execute()
                st.success(f"📨 Presupuesto creado para {razon}.")
            except Exception as e:
                st.error(f"❌ Error creando presupuesto: {e}")

    with ccol:
        if st.button("🗑️ Eliminar", key=f"elim_cli_{c['clienteid']}", use_container_width=True):
            st.session_state.update({
                "cliente_modal_id": c["clienteid"],
                "confirm_delete": True,
                "show_cliente_modal": True,
            })
            st.rerun()


# =========================================================
# 🧾 Tabla
# =========================================================
def _render_table(clientes, supabase):
    df = pd.DataFrame(clientes)
    if df.empty:
        st.info("No hay clientes.")
        return

    df["estado"] = df["estadoid"].apply(lambda x: get_estado_label(x, supabase))
    df["categoria"] = df["categoriaid"].apply(lambda x: get_categoria_label(x, supabase))
    df["grupo"] = df["grupoid"].apply(lambda x: get_grupo_label(x, supabase))
    df["trabajador"] = df["trabajadorid"].apply(lambda x: get_trabajador_label(x, supabase))
    df["forma_pago"] = df["formapagoid"].apply(lambda x: get_formapago_label(x, supabase))

    st.dataframe(df, use_container_width=True)

    buff = io.StringIO()
    df.to_csv(buff, index=False)
    st.download_button(
        "⬇️ Exportar CSV",
        buff.getvalue(),
        file_name=f"clientes_{date.today().isoformat()}.csv",
        mime="text/csv",
    )

# =========================================================
# 🧩 Modal de ficha completa de cliente
# =========================================================
from datetime import date
import streamlit as st
from modules.cliente_direccion_form import render_direccion_form
from modules.cliente_facturacion_form import render_facturacion_form
from modules.cliente_observacion_form import render_observaciones_form
from modules.cliente_crm_form import render_crm_form
from modules.cliente_documento_form import render_documento_form


def render_cliente_modal(supabase):
    """Muestra la ficha completa del cliente en modo modal."""
    clienteid = st.session_state.get("cliente_modal_id")
    if not clienteid:
        return

    # ---------------------------------------------
    # 🏢 Cabecera visual del modal
    # ---------------------------------------------
    st.markdown("---")
    st.markdown(
        """
        <div style="padding:16px;background:#eef2ff;border-radius:10px;margin-bottom:10px;">
            <h3 style="margin:0;">🏢 Ficha del cliente</h3>
            <p style="color:#555;margin:4px 0;">Consulta, edita y gestiona toda la información relacionada con este cliente.</p>
        </div>
        """,
        unsafe_allow_html=True,
    )

    # ---------------------------------------------
    # 🔙 Botones superiores (cerrar / eliminar)
    # ---------------------------------------------
    col_close, col_delete = st.columns([2, 1])
    with col_close:
        if st.button("⬅️ Cerrar ficha", width="stretch"):
            st.session_state.update({"show_cliente_modal": False, "confirm_delete": False})
            st.rerun()

    with col_delete:
        if st.session_state.get("confirm_delete"):
            col_d1, col_d2 = st.columns(2)
            with col_d1:
                if st.button("❌ Cancelar", width="stretch"):
                    st.session_state["confirm_delete"] = False
                    st.rerun()
            with col_d2:
                if st.button("✅ Confirmar eliminación", width="stretch"):
                    try:
                        supabase.table("cliente").delete().eq("clienteid", clienteid).execute()
                        st.success("🗑️ Cliente eliminado correctamente.")
                        st.session_state.update({"show_cliente_modal": False, "confirm_delete": False})
                        st.rerun()
                    except Exception as e:
                        st.error(f"❌ Error al eliminar cliente: {e}")
        else:
            st.button("🗑️ Eliminar cliente", width="stretch")

    # =========================================================
    # 🧾 Formularios seccionales
    # =========================================================
    st.markdown("---")
    st.subheader("📦 Direcciones del cliente")
    render_direccion_form(supabase, clienteid, modo="cliente")

    st.markdown("---")
    st.subheader("💳 Datos de facturación")
    render_facturacion_form(supabase, clienteid)


    # =========================================================
    # 👥 Contactos del cliente
    # =========================================================
    st.markdown("---")
    st.subheader("👥 Contactos del cliente")
    from modules.cliente_contacto_form import render_contacto_form
    render_contacto_form(supabase, clienteid)


    st.markdown("---")
    st.subheader("🗒️ Observaciones internas")
    render_observaciones_form(supabase, clienteid)

    # =========================================================
    # 📎 Documentos del cliente (manual + futuro SharePoint)
    # =========================================================
    st.markdown("---")
    st.subheader("📎 Documentos asociados")
    st.caption("Adjunta documentos (contratos, SEPA, FACE, albaranes, etc.) o sincroniza con SharePoint.")

    # Botón placeholder de sincronización
    if st.button("🔄 Sincronizar desde SharePoint (próximamente)", width="stretch"):
        st.info("🕓 Conexión con SharePoint aún no disponible. Este botón permitirá importar metadatos y URLs automáticamente.")

    # Render del formulario/documentos registrados
    render_documento_form(supabase, clienteid)

    # =========================================================
    # 💬 CRM / Seguimientos
    # =========================================================
    st.markdown("---")
    st.subheader("💬 Seguimiento y CRM")
    render_crm_form(supabase, clienteid)

    # =========================================================
    # 💼 Historial de presupuestos
    # =========================================================
    st.markdown("---")
    st.subheader("💼 Historial de presupuestos")
    try:
        pres = (
            supabase.table("presupuesto")
            .select("presupuestoid, estado_presupuestoid, fecha_presupuesto, total_estimada")
            .eq("clienteid", clienteid)
            .order("fecha_presupuesto", desc=True)
            .execute()
        )

        if not pres.data:
            st.info("⚙️ Este cliente no tiene presupuestos registrados.")
        else:
            estado_map = {1: "Pendiente", 2: "Aceptado", 3: "Rechazado"}
            for p in pres.data:
                estado = estado_map.get(p["estado_presupuestoid"], "Desconocido")
                color = {
                    "Pendiente": "#f59e0b",
                    "Aceptado": "#16a34a",
                    "Rechazado": "#dc2626"
                }.get(estado, "#6b7280")
                st.markdown(
                    f"<div style='border-left:5px solid {color};padding:6px 10px;margin:4px 0;border-radius:6px;'>"
                    f"🗓️ <b>{p['fecha_presupuesto']}</b> — "
                    f"<span style='color:{color};font-weight:600;'>{estado}</span> — "
                    f"💰 {p.get('total_estimada','-')} €</div>",
                    unsafe_allow_html=True,
                )
    except Exception as e:
        st.warning(f"⚠️ No se pudo cargar el historial de presupuestos: {e}")

    # Botón crear nuevo presupuesto
    if st.button("📨 Crear nuevo presupuesto", width="stretch"):
        try:
            supabase.table("presupuesto").insert({
                "numero": f"PRES-{date.today().year}-{clienteid}",
                "clienteid": clienteid,
                "trabajadorid": st.session_state.get("trabajadorid", 13),
                "estado_presupuestoid": 1,  # Pendiente
                "fecha_presupuesto": date.today().isoformat(),
                "observaciones": "Presupuesto creado desde ficha del cliente.",
                "editable": True,
                "facturar_individual": False,
            }).execute()
            st.success("📨 Nuevo presupuesto creado.")
            st.rerun()
        except Exception as e:
            st.error(f"❌ Error al crear presupuesto: {e}")



