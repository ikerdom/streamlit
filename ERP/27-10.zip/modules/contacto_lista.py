import streamlit as st
from datetime import datetime

def render_contacto_lista(supabase, clienteid=None):
    """
    📇 Lista de contactos del cliente actual o de un cliente específico.
    - Si se pasa clienteid → muestra los contactos de ese cliente.
    - Si no → usa el cliente activo en sesión.
    - Permite filtrar, ver todos y añadir nuevos contactos.
    """
    st.header("📇 Contactos del cliente")
    st.caption("Consulta o gestiona los contactos asociados al cliente actual.")

    # -------------------------------------------------------
    # 📌 Determinar cliente
    # -------------------------------------------------------
    if not clienteid:
        clienteid = st.session_state.get("cliente_actual")

    if not clienteid:
        st.warning("⚠️ No hay ningún cliente activo en sesión.")
        st.info("Inicia sesión o crea un cliente para ver sus contactos.")
        return

    try:
        cliente = (
            supabase.table("cliente")
            .select("razon_social, identificador")
            .eq("clienteid", clienteid)
            .single()
            .execute()
        )
        if cliente.data:
            st.markdown(f"### 🏢 {cliente.data['razon_social']}")
            st.caption(f"Identificador: `{cliente.data['identificador']}`")
    except Exception:
        st.warning("No se pudo recuperar la información del cliente.")

    st.markdown("---")

    # -------------------------------------------------------
    # 🔍 Filtros de visualización
    # -------------------------------------------------------
    cols = st.columns([1, 1])
    with cols[0]:
        ver_todos = st.checkbox("👥 Ver todos los contactos", value=False)
    with cols[1]:
        filtro = st.text_input("🔎 Buscar por nombre o email", key="filtro_contacto")

    # -------------------------------------------------------
    # 📋 Mostrar contactos
    # -------------------------------------------------------
    try:
        query = (
            supabase.table("cliente_contacto")
            .select(
                "cliente_contactoid, nombre, telefono, email, rol, cargo, es_principal, observaciones, pais"
            )
            .eq("clienteid", clienteid)
        )

        if not ver_todos:
            query = query.eq("es_principal", True)

        contactos = query.order("nombre", desc=False).execute()

        if contactos.data:
            filtrados = [
                c for c in contactos.data
                if not filtro
                or filtro.lower() in (c.get("nombre", "").lower() + c.get("email", "").lower())
            ]

            if not filtrados:
                st.info("No hay contactos que coincidan con la búsqueda.")
                return

            for c in filtrados:
                col1, col2 = st.columns([2, 1])
                with col1:
                    st.markdown(f"**👤 {c['nombre']}**")
                    email_str = (
                        f"[{c.get('email','-')}](mailto:{c['email']})"
                        if c.get("email")
                        else "-"
                    )
                    st.caption(f"📧 {email_str} | 📞 {c.get('telefono','-')}")
                    if c.get("rol"):
                        st.caption(f"🎯 Rol: {c['rol']}")
                    if c.get("cargo"):
                        st.caption(f"🏢 Cargo: {c['cargo']}")
                    if c.get("pais"):
                        st.caption(f"🌍 País: {c['pais']}")
                    if c.get("observaciones"):
                        st.text_area(
                            "🗒️ Notas",
                            value=c["observaciones"],
                            disabled=True,
                            height=60,
                            key=f"obs_{c['cliente_contactoid']}",
                        )
                with col2:
                    estado = "⭐ Principal" if c.get("es_principal") else ""
                    st.markdown(estado)
                st.markdown("---")
        else:
            st.info("No hay contactos registrados para este cliente.")

    except Exception as e:
        st.error(f"❌ Error al cargar los contactos: {e}")

    # -------------------------------------------------------
    # ➕ Añadir nuevo contacto
    # -------------------------------------------------------
    st.subheader("➕ Añadir nuevo contacto")

    with st.form("form_nuevo_contacto"):
        nombre = st.text_input("Nombre completo *", key="nuevo_nombre")
        email = st.text_input("Correo electrónico", key="nuevo_email")
        telefono = st.text_input("Teléfono", key="nuevo_telefono")
        rol = st.text_input("Rol", placeholder="Compras, Contabilidad, etc.", key="nuevo_rol")
        cargo = st.text_input("Cargo", key="nuevo_cargo")
        pais = st.text_input("País", value="España", key="nuevo_pais")
        observaciones = st.text_area(
            "Observaciones", key="nuevo_obs", placeholder="Notas o comentarios adicionales..."
        )
        es_principal = st.checkbox(
            "Marcar como contacto principal", value=False, key="nuevo_principal"
        )
        submitted = st.form_submit_button("💾 Guardar contacto")

    if submitted:
        if not nombre.strip():
            st.warning("⚠️ El nombre es obligatorio.")
            return
        try:
            data = {
                "clienteid": clienteid,
                "nombre": nombre.strip(),
                "email": email.strip() or None,
                "telefono": telefono.strip() or None,
                "rol": rol.strip() or None,
                "cargo": cargo.strip() or None,
                "pais": pais.strip() or None,
                "observaciones": observaciones.strip() or None,
                "es_principal": es_principal,
            }
            res = supabase.table("cliente_contacto").insert(data).execute()
            if res.data:
                nuevo_id = res.data[0]["cliente_contactoid"]
                st.success(f"✅ Contacto '{nombre}' añadido correctamente (ID {nuevo_id}).")
                st.rerun()
            else:
                st.error("❌ No se pudo insertar el contacto.")
        except Exception as e:
            st.error(f"❌ Error al guardar el contacto: {e}")
