import streamlit as st
from datetime import datetime

def _has_table(supabase, table_name: str) -> bool:
    try:
        supabase.table(table_name).select("*").limit(1).execute()
        return True
    except Exception:
        return False


def render_observaciones_form(supabase, clienteid: int):
    """Gestión de observaciones internas del cliente."""
    st.markdown("### 🗒️ Observaciones internas")
    st.caption("Notas privadas o de seguimiento asociadas al cliente.")

    use_obs_table = _has_table(supabase, "cliente_observacion")

    # -------------------------------------------------
    # 📋 Listado de observaciones existentes
    # -------------------------------------------------
    try:
        if use_obs_table:
            notas = (
                supabase.table("cliente_observacion")
                .select("cliente_observacionid, comentario, tipo, fecha, usuario")
                .eq("clienteid", clienteid)
                .order("fecha", desc=True)
                .execute()
                .data or []
            )
        else:
            rows = (
                supabase.table("cliente_parametro")
                .select("clave, valor")
                .eq("clienteid", clienteid)
                .execute()
                .data or []
            )
            notas = [
                {"cliente_observacionid": i, "tipo": r["clave"], "comentario": r["valor"], "fecha": "-", "usuario": "-"}
                for i, r in enumerate(rows)
                if str(r["clave"]).startswith("observacion_")
            ]
    except Exception as e:
        st.error(f"❌ Error cargando observaciones: {e}")
        return

    if notas:
        for n in notas:
            st.markdown(f"**{n.get('tipo','-')}** — {n.get('fecha','-')} · {n.get('usuario','-')}")
            st.write(f"> {n.get('comentario','')}")
            st.markdown("---")
    else:
        st.info("📭 No hay observaciones registradas aún.")

    # -------------------------------------------------
    # ➕ Añadir observación (expander cerrado)
    # -------------------------------------------------
    with st.expander("➕ Añadir nueva observación", expanded=False):
        col1, col2 = st.columns(2)
        with col1:
            tipo = st.selectbox("Tipo", ["General", "Comercial", "Administración", "Otro"], index=0)
        with col2:
            usuario = st.session_state.get("user_nombre", "Desconocido")

        comentario = st.text_area("Comentario", placeholder="Escribe tu nota…", height=100)
        if st.button("💾 Guardar observación", use_container_width=True):
            if not comentario.strip():
                st.warning("⚠️ Debes escribir un comentario.")
                return
            try:
                if use_obs_table:
                    supabase.table("cliente_observacion").insert({
                        "clienteid": clienteid,
                        "tipo": tipo,
                        "comentario": comentario.strip(),
                        "usuario": usuario,
                        "fecha": datetime.now().isoformat(),
                    }).execute()
                else:
                    supabase.table("cliente_parametro").upsert({
                        "clienteid": clienteid,
                        "clave": f"observacion_{tipo.lower()}",
                        "valor": comentario.strip(),
                    }, on_conflict="clienteid,clave").execute()

                st.toast("✅ Observación guardada correctamente.", icon="✅")
                st.rerun()
            except Exception as e:
                st.error(f"❌ Error guardando observación: {e}")
