# modules/cliente_potencial_lista.py
import streamlit as st
import math
from datetime import date
from modules.cliente_models import (
    load_estados_cliente,
    load_categorias,
    load_grupos,
    load_trabajadores,
    get_estado_label,
    get_categoria_label,
    get_grupo_label,
    get_trabajador_label,
)


# ==========================================================
# 🌱 VISTA PRINCIPAL — CLIENTES POTENCIALES
# ==========================================================
def render_cliente_potencial_lista(supabase):
    st.header("🌱 Gestión de clientes potenciales")
    st.caption("Visualiza tus clientes potenciales, completa su perfil y conviértelos en clientes activos cuando estén listos.")

    trabajadorid = st.session_state.get("trabajadorid", 13)
    st.session_state.setdefault("pot_page", 1)

    page_size = 9
    estados = load_estados_cliente(supabase)
    categorias = load_categorias(supabase)
    grupos = load_grupos(supabase)
    trabajadores = load_trabajadores(supabase)

    # ------------------------------
    # 🎛️ Filtros
    # ------------------------------
    colf1, colf2, colf3 = st.columns([2, 2, 1])
    with colf1:
        q = st.text_input("🔎 Buscar", placeholder="Razón social o identificador…", key="pot_q")
    with colf2:
        perfil_sel = st.selectbox("Perfil", ["Todos", "Completos", "Incompletos"], key="pot_perfil")
    with colf3:
        st.write("")
        ver_todos = st.toggle("👀 Ver todos los potenciales", value=False)

    st.markdown("---")

    # ------------------------------
    # 📊 Query principal
    # ------------------------------
    total = 0
    potenciales = []

    try:
        base = (
            supabase.table("cliente")
            .select("clienteid, razon_social, identificador, estadoid, categoriaid, grupoid, trabajadorid, perfil_completo")
            .eq("tipo_cliente", "potencial")
        )

        if q:
            base = base.or_(f"razon_social.ilike.%{q}%,identificador.ilike.%{q}%")
        if not ver_todos:
            base = base.eq("trabajadorid", trabajadorid)
        if perfil_sel != "Todos":
            base = base.eq("perfil_completo", perfil_sel == "Completos")

        base = base.order("razon_social", desc=False)
        data = base.execute()
        potenciales = data.data or []
        total = len(potenciales)
    except Exception as e:
        st.error(f"❌ Error cargando clientes potenciales: {e}")

    st.caption(f"Mostrando {total} potenciales {'(todos)' if ver_todos else '(solo los tuyos)'}")
    st.markdown("---")

    if not potenciales:
        st.info("📭 No hay clientes potenciales para mostrar.")
        return

    # ------------------------------
    # 🧾 Renderizado de tarjetas
    # ------------------------------
    cols = st.columns(3)
    for i, c in enumerate(potenciales):
        with cols[i % 3]:
            _render_potencial_card(c, supabase)

    # ------------------------------
    # 📑 Paginación
    # ------------------------------
    st.markdown("---")
    total_pages = max(1, math.ceil(total / page_size))
    colp1, colp2, _ = st.columns([1, 1, 6])
    with colp1:
        if st.button("◀️", disabled=st.session_state.pot_page <= 1):
            st.session_state.pot_page -= 1
            st.rerun()
    with colp2:
        if st.button("▶️", disabled=st.session_state.pot_page >= total_pages):
            st.session_state.pot_page += 1
            st.rerun()

    # Modal activo
    render_potencial_modal(supabase)


# ==========================================================
# 💳 TARJETA DE CLIENTE POTENCIAL
# ==========================================================
def _render_potencial_card(c, supabase):
    razon = c.get("razon_social", "-")
    ident = c.get("identificador", "-")
    estado = get_estado_label(c.get("estadoid"), supabase)
    categoria = get_categoria_label(c.get("categoriaid"), supabase)
    grupo = get_grupo_label(c.get("grupoid"), supabase)
    trabajador = get_trabajador_label(c.get("trabajadorid"), supabase)
    completo = c.get("perfil_completo", False)

    perfil_html = (
        '<span style="color:#16a34a;font-weight:600;">🟢 Perfil completo</span>'
        if completo else
        '<span style="color:#dc2626;font-weight:600;">🔴 Faltan datos</span>'
    )

    st.markdown(
        f"""
        <div style="border:1px solid #e5e7eb;border-radius:12px;padding:12px;margin-bottom:10px;background:#f9fafb;">
            <b>{razon}</b> <span style="color:#6b7280;">({ident})</span><br>
            🏷️ <b>Estado:</b> {estado}<br>
            🧩 <b>Categoría:</b> {categoria}<br>
            👥 <b>Grupo:</b> {grupo}<br>
            🧑 <b>Trabajador:</b> {trabajador}<br>
            {perfil_html}
        </div>
        """,
        unsafe_allow_html=True,
    )

    colA, colB, colC = st.columns([1, 1, 2])

    with colA:
        if st.button("📄 Ficha", key=f"ficha_pot_{c['clienteid']}", width="stretch"):
            st.session_state.update({
                "cliente_actual": c["clienteid"],
                "show_potencial_modal": True,
                "confirm_delete": False
            })
            st.rerun()

    with colB:
        if st.button("📨 Presupuesto", key=f"pres_pot_{c['clienteid']}", width="stretch"):
            try:
                supabase.table("presupuesto").insert({
                    "clienteid": c["clienteid"],
                    "fecha_presupuesto": date.today().isoformat(),
                    "estado_presupuestoid": 1
                }).execute()
                st.success(f"📨 Presupuesto creado para {razon}.")
            except Exception as e:
                st.error(f"❌ Error creando presupuesto: {e}")

    with colC:
        if completo:
            if st.button("🚀 Convertir a cliente", key=f"conv_{c['clienteid']}", width="stretch"):
                try:
                    supabase.table("cliente").update(
                        {"tipo_cliente": "cliente", "estadoid": 1}
                    ).eq("clienteid", c["clienteid"]).execute()
                    st.success(f"🎉 {razon} convertido a cliente.")
                    st.rerun()
                except Exception as e:
                    st.error(f"❌ Error al convertir: {e}")
        else:
            st.button("❌ Incompleto", key=f"no_conv_{c['clienteid']}", width="stretch", disabled=True)
# ==========================================================
# 🧩 MODAL DE FICHA COMPLETA — DETALLE + EDICIÓN
# ==========================================================
def render_potencial_modal(supabase):
    if not st.session_state.get("show_potencial_modal"):
        return

    clienteid = st.session_state.get("cliente_actual")
    if not clienteid:
        st.warning("⚠️ No hay cliente activo.")
        return

    st.markdown("---")
    st.markdown(
        """
        <div style="padding:16px;background:#eef2ff;border-radius:10px;margin-bottom:10px;">
            <h3 style="margin:0;">🌱 Ficha del cliente potencial</h3>
            <p style="color:#555;margin:4px 0;">Consulta los detalles y edita los formularios para completar su perfil.</p>
        </div>
        """,
        unsafe_allow_html=True,
    )

    # ------------------------------
    # BOTONES SUPERIORES
    # ------------------------------
    col_close, col_delete, col_pres = st.columns([2, 1, 1])
    with col_close:
        if st.button("⬅️ Cerrar ficha", width="stretch"):
            st.session_state.update({
                "show_potencial_modal": False,
                "confirm_delete": False
            })
            st.rerun()

    with col_delete:
        if not st.session_state.get("confirm_delete"):
            if st.button("🗑️ Eliminar cliente", width="stretch"):
                st.session_state["confirm_delete"] = True
                st.warning("⚠️ Pulsa **Confirmar eliminación** para borrar definitivamente este cliente.")
        else:
            col_d1, col_d2 = st.columns(2)
            with col_d1:
                if st.button("❌ Cancelar", width="stretch"):
                    st.session_state["confirm_delete"] = False
                    st.experimental_rerun()
            with col_d2:
                if st.button("✅ Confirmar eliminación", width="stretch"):
                    try:
                        supabase.table("cliente").delete().eq("clienteid", clienteid).execute()
                        st.success("🗑️ Cliente eliminado correctamente.")
                        st.session_state.update({
                            "show_potencial_modal": False,
                            "confirm_delete": False
                        })
                        st.rerun()
                    except Exception as e:
                        st.error(f"❌ Error al eliminar cliente: {e}")

    with col_pres:
        if st.button("📨 Crear presupuesto", width="stretch"):
            try:
                supabase.table("presupuesto").insert({
                    "clienteid": clienteid,
                    "fecha_presupuesto": date.today().isoformat(),
                    "estado_presupuestoid": 1
                }).execute()
                st.success("📨 Presupuesto creado correctamente.")
            except Exception as e:
                st.error(f"❌ Error creando presupuesto: {e}")

    # ------------------------------
    # 🔎 DETALLE DEL CLIENTE
    # ------------------------------
    try:
        cli = (
            supabase.table("cliente")
            .select("clienteid, razon_social, formapagoid, trabajadorid, observaciones, perfil_completo, tipo_cliente")
            .eq("clienteid", clienteid)
            .single()
            .execute()
            .data
        )

        dir_fiscal = (
            supabase.table("cliente_direccion")
            .select("direccion, ciudad, provincia, cp, pais")
            .eq("clienteid", clienteid)
            .eq("tipo", "fiscal")
            .limit(1)
            .execute()
            .data
        )

        tiene_dir = bool(dir_fiscal and dir_fiscal[0].get("direccion") and dir_fiscal[0].get("cp"))
        tiene_pago = bool(cli.get("formapagoid"))
        tiene_trab = bool(cli.get("trabajadorid"))

        faltan = []
        if not tiene_dir:
            faltan.append("Dirección fiscal (con CP)")
        if not tiene_pago:
            faltan.append("Forma de pago")
        if not tiene_trab:
            faltan.append("Trabajador asignado")

        perfil_ok = not faltan

        with st.expander("🔎 Estado del perfil", expanded=True):
            st.write(f"**Razón social:** {cli.get('razon_social','-')}")
            st.write(f"**Tipo:** {cli.get('tipo_cliente','-')}")
            st.write(f"**Forma de pago:** {cli.get('formapagoid') or '-'}")
            st.write(f"**Trabajador asignado:** {cli.get('trabajadorid') or '-'}")
            st.write("**Observaciones:**")
            st.info(cli.get("observaciones") or "-")

            st.markdown(
                f"""
                <div style="background:{'#dcfce7' if perfil_ok else '#fef3c7'};border:1px solid {'#16a34a' if perfil_ok else '#fcd34d'};
                    padding:10px;border-radius:8px;margin-top:10px;">
                    <b>📋 Estado del perfil:</b><br>
                    {'✅ Dirección fiscal añadida' if tiene_dir else '❌ Sin dirección fiscal o CP'}<br>
                    {'✅ Forma de pago definida' if tiene_pago else '❌ Sin forma de pago'}<br>
                    {'✅ Trabajador asignado' if tiene_trab else '❌ Sin trabajador asignado'}<br><br>
                    {("<span style='color:#16a34a;font-weight:600;'>Todo correcto</span>" 
                    if perfil_ok else "".join([f"<span style='color:#dc2626'>• {m}</span><br>" for m in faltan]))}
                </div>
                """,
                unsafe_allow_html=True,
            )

            # Actualizar flag perfil_completo automáticamente
            try:
                supabase.table("cliente").update({"perfil_completo": perfil_ok}).eq("clienteid", clienteid).execute()
            except Exception:
                pass
    except Exception as e:
        st.warning(f"⚠️ No se pudo cargar detalle: {e}")

    # ------------------------------
    # ✏️ FORMULARIOS DE EDICIÓN
    # ------------------------------
    from modules.cliente_direccion_form import render_direccion_form
    from modules.cliente_facturacion_form import render_facturacion_form
    from modules.cliente_observacion_form import render_observaciones_form
    from modules.cliente_crm_form import render_crm_form

    st.session_state["cliente_actual"] = clienteid

    st.markdown("---")
    st.subheader("✏️ Editar datos del cliente potencial")

    render_direccion_form(supabase, clienteid, modo="potencial")
    st.markdown("---")
    render_facturacion_form(supabase, clienteid)
    st.markdown("---")
    render_observaciones_form(supabase, clienteid)
    st.markdown("---")
    render_crm_form(supabase, clienteid)
